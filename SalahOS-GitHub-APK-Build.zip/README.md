# SalahOS — Android Studio project
1. Android Studio (Koala+ / JDK 17) → File > Open → এই ফোল্ডার।
2. Gradle Sync শেষ হতে দিন (ইন্টারনেট লাগবে, শুধু প্রথমবার)।
3. Build > Build Bundle(s)/APK(s) > Build APK(s)  → app/build/outputs/apk/debug/app-debug.apk
4. ফোনে APK কপি করে ইন্সটল করুন ("Unknown sources" অনুমতি দিন)।
ওয়েব ফাইল: app/src/main/assets/www/ (এখানে সম্পাদনা করলেই অ্যাপে আপডেট হবে)।
