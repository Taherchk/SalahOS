// service-worker.js — offline-first cache for SalahOS app shell + data.
const CACHE_NAME = "salahos-cache-v3";
const CORE_ASSETS = [
  "./",
  "./index.html",
  "./style.css",
  "./manifest.json",
  "./js/app.js",
  "./js/router.js",
  "./js/storage.js",
  "./js/indexeddb.js",
  "./js/ui.js",
  "./js/data.js",
  "./js/audio.js",
  "./js/favorites.js",
  "./js/surah.js",
  "./js/salah.js",
  "./js/dua.js",
  "./js/dhikr.js",
  "./js/quiz.js",
  "./js/memorization.js",
  "./js/prayer-time.js",
  "./js/tracker.js",
  "./js/search.js",
  "./js/notifications.js",
  "./js/settings.js",
  "./js/fiqh.js",
  "./js/ramadan.js",
  "./js/guides.js",
  "./js/qibla.js",
  "./data/surahs.json",
  "./data/salah_recitations.json",
  "./data/duas.json",
  "./data/dhikr.json",
  "./data/salah_steps.json",
  "./data/fiqh.json",
  "./data/quiz.json",
  "./data/terms.json",
  "./data/guides.json",
  "./assets/icons/icon.svg",
  "./assets/icons/icon-maskable.svg",
  "./assets/icons/icon-192.png",
  "./assets/icons/icon-512.png",
  "./assets/icons/icon-maskable-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(CORE_ASSETS))
      .catch((err) => console.warn("SalahOS SW install cache error", err))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  event.respondWith(
    caches.match(event.request).then((cached) => {
      const networkFetch = fetch(event.request)
        .then((response) => {
          if (response && response.ok) {
            const copy = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy)).catch(() => {});
          }
          return response;
        })
        .catch(() => cached);
      return cached || networkFetch;
    })
  );
});
