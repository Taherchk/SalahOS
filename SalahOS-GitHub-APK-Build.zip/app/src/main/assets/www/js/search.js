// search.js — global search across surahs, duas, dhikr, salah recitations, fiqh.
import { getSurahs, getSalahRecitations, getDuas, getDhikr, getFiqh } from "./data.js";
import { getItem, setItem, KEYS } from "./storage.js";
import { esc } from "./ui.js";

function norm(s) { return (s || "").toLowerCase().normalize("NFC"); }

export async function searchAll(query) {
  const q = norm(query);
  if (!q) return [];
  const results = [];

  const surahs = await getSurahs();
  surahs.forEach((s) => {
    if (norm(s.nameBangla).includes(q) || norm(s.nameEnglish).includes(q)) {
      results.push({ category: "সূরা", title: s.nameBangla, route: "surah-reader", params: { id: s.id } });
    }
  });

  const recs = await getSalahRecitations();
  recs.forEach((r) => {
    if (norm(r.titleBn).includes(q) || norm(r.category).includes(q) || norm(r.meaningBn).includes(q)) {
      results.push({ category: "সালাহ রিসাইটেশন", title: r.titleBn, route: "salah", params: {} });
    }
  });

  const duas = await getDuas();
  duas.forEach((d) => {
    if (norm(d.titleBn).includes(q) || norm(d.meaningBn).includes(q)) {
      results.push({ category: "দুআ", title: d.titleBn, route: "duas", params: {} });
    }
  });

  const dhikrs = await getDhikr();
  dhikrs.forEach((d) => {
    if (norm(d.titleBn).includes(q) || norm(d.meaningBn).includes(q)) {
      results.push({ category: "যিকর", title: d.titleBn, route: "dhikr", params: {} });
    }
  });

  const fiqh = await getFiqh();
  fiqh.forEach((f) => {
    if (norm(f.titleBn).includes(q) || norm(f.bodyBn).includes(q)) {
      results.push({ category: "ফিকহ নোট", title: f.titleBn, route: "fiqh", params: {} });
    }
  });

  return results;
}

export function getRecentSearches() { return getItem(KEYS.RECENT_SEARCHES, []); }
export function addRecentSearch(q) {
  if (!q || !q.trim()) return;
  let list = getRecentSearches().filter((x) => x !== q);
  list.unshift(q);
  list = list.slice(0, 8);
  setItem(KEYS.RECENT_SEARCHES, list);
}

export function renderResults(results) {
  if (!results.length) return `<p class="muted text-center" style="margin-top:20px;">কোনো ফলাফল পাওয়া যায়নি।</p>`;
  return results.map((r) => `
    <div class="list-item" data-nav="${r.route}${Object.keys(r.params).length ? "?" + new URLSearchParams(r.params).toString() : ""}">
      <span>${esc(r.title)}</span>
      <span class="badge">${esc(r.category)}</span>
    </div>`).join("");
}
