// prayer-time.js — astronomical prayer-time calculation.
// Based on standard solar-angle formulas (declination, equation of time, hour angle)
// used across widely-published open prayer-time calculators. Results are an
// approximation; actual observed times may vary slightly by locale/authority.
import { getItem, setItem, KEYS } from "./storage.js";

export const METHODS = {
  MWL: { fajr: 18, isha: 17, name: "Muslim World League" },
  ISNA: { fajr: 15, isha: 15, name: "ISNA" },
  Egyptian: { fajr: 19.5, isha: 17.5, name: "Egyptian General Authority" },
  Karachi: { fajr: 18, isha: 18, name: "University of Karachi" },
  UmmAlQura: { fajr: 18.5, ishaMinutes: 90, name: "Umm al-Qura" },
};

export const CITIES = {
  "Dhaka,BD": { name: "ঢাকা, বাংলাদেশ", lat: 23.8103, lng: 90.4125, tz: 6 },
  "Chittagong,BD": { name: "চট্টগ্রাম, বাংলাদেশ", lat: 22.3569, lng: 91.7832, tz: 6 },
  "Sylhet,BD": { name: "সিলেট, বাংলাদেশ", lat: 24.8949, lng: 91.8687, tz: 6 },
  "Mecca,SA": { name: "মক্কা, সৌদি আরব", lat: 21.3891, lng: 39.8579, tz: 3 },
  "Medina,SA": { name: "মদিনা, সৌদি আরব", lat: 24.5247, lng: 39.5692, tz: 3 },
  "Dubai,AE": { name: "দুবাই, আরব আমিরাত", lat: 25.2048, lng: 55.2708, tz: 4 },
  "London,UK": { name: "লন্ডন, যুক্তরাজ্য", lat: 51.5072, lng: -0.1276, tz: 0 },
  "NewYork,US": { name: "নিউ ইয়র্ক, যুক্তরাষ্ট্র", lat: 40.7128, lng: -74.0060, tz: -5 },
};

function deg2rad(d) { return (d * Math.PI) / 180; }
function rad2deg(r) { return (r * 180) / Math.PI; }
function fixAngle(a) { a = a % 360; if (a < 0) a += 360; return a; }
function fixHour(h) { h = h % 24; if (h < 0) h += 24; return h; }

// Julian date for a given UTC calendar date (y, m, d)
function julianDate(y, m, d) {
  if (m <= 2) { y -= 1; m += 12; }
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
}

function sunPosition(jd) {
  const D = jd - 2451545.0;
  const g = fixAngle(357.529 + 0.98560028 * D);
  const q = fixAngle(280.459 + 0.98564736 * D);
  const L = fixAngle(q + 1.915 * Math.sin(deg2rad(g)) + 0.020 * Math.sin(deg2rad(2 * g)));
  const e = 23.439 - 0.00000036 * D;
  const RA = fixAngle(rad2deg(Math.atan2(Math.cos(deg2rad(e)) * Math.sin(deg2rad(L)), Math.cos(deg2rad(L)))));
  let eqt = q / 15 - RA / 15;
  if (eqt > 12) eqt -= 24; if (eqt < -12) eqt += 24;
  const decl = rad2deg(Math.asin(Math.sin(deg2rad(e)) * Math.sin(deg2rad(L))));
  return { declination: decl, eqt };
}

function computeTime(angle, lat, decl, eqt, lng, tz, isSunrise) {
  const cosH = (-Math.sin(deg2rad(angle)) - Math.sin(deg2rad(lat)) * Math.sin(deg2rad(decl))) /
    (Math.cos(deg2rad(lat)) * Math.cos(deg2rad(decl)));
  if (cosH > 1 || cosH < -1) return null; // sun never reaches this angle (polar regions)
  const H = rad2deg(Math.acos(cosH)) / 15;
  const T = 12 + tz - lng / 15 - eqt;
  return isSunrise ? T - H : T + H;
}

function asrTime(lat, decl, eqt, lng, tz, shadowFactor) {
  const tanInv = rad2deg(Math.atan(1 / (shadowFactor + Math.tan(deg2rad(Math.abs(lat - decl))))));
  const H = rad2deg(Math.acos(
    (Math.sin(deg2rad(tanInv)) - Math.sin(deg2rad(lat)) * Math.sin(deg2rad(decl))) /
    (Math.cos(deg2rad(lat)) * Math.cos(deg2rad(decl)))
  )) / 15;
  const T = 12 + tz - lng / 15 - eqt;
  return T + H;
}

function hoursToHHMM(h) {
  if (h == null || isNaN(h)) return "—";
  h = fixHour(h);
  const hh = Math.floor(h);
  const mm = Math.round((h - hh) * 60);
  const mm2 = mm === 60 ? 0 : mm;
  const hh2 = mm === 60 ? hh + 1 : hh;
  const period = hh2 >= 12 ? "PM" : "AM";
  let h12 = hh2 % 12; if (h12 === 0) h12 = 12;
  return `${String(h12).padStart(2, "0")}:${String(mm2).padStart(2, "0")} ${period}`;
}

export function calculateTimes({ lat, lng, tz, date = new Date(), method = "MWL", asrMethod = "Standard" }) {
  const jd = julianDate(date.getUTCFullYear(), date.getUTCMonth() + 1, date.getUTCDate());
  const { declination: decl, eqt } = sunPosition(jd);
  const m = METHODS[method] || METHODS.MWL;
  const shadowFactor = asrMethod === "Hanafi" ? 2 : 1;

  const fajr = computeTime(m.fajr, lat, decl, eqt, lng, tz, true);
  const sunrise = computeTime(0.833, lat, decl, eqt, lng, tz, true);
  const dhuhrBase = 12 + tz - lng / 15 - eqt;
  const asr = asrTime(lat, decl, eqt, lng, tz, shadowFactor);
  const maghrib = computeTime(0.833, lat, decl, eqt, lng, tz, false);
  let isha;
  if (m.ishaMinutes) isha = maghrib != null ? maghrib + m.ishaMinutes / 60 : null;
  else isha = computeTime(m.isha, lat, decl, eqt, lng, tz, false);

  return {
    fajr: hoursToHHMM(fajr), sunrise: hoursToHHMM(sunrise), dhuhr: hoursToHHMM(dhuhrBase + 0.0333),
    asr: hoursToHHMM(asr), maghrib: hoursToHHMM(maghrib), isha: hoursToHHMM(isha),
    raw: { fajr, sunrise, dhuhr: dhuhrBase + 0.0333, asr, maghrib, isha },
    method: m.name, asrMethod,
  };
}

export function getLocationSettings() {
  return getItem(KEYS.LOCATION, { mode: "manual", city: "Dhaka,BD", method: "MWL", asrMethod: "Standard" });
}
export function setLocationSettings(s) { setItem(KEYS.LOCATION, s); }

export async function requestGeolocation() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) { reject(new Error("Geolocation not supported")); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      (err) => reject(err),
      { timeout: 8000 }
    );
  });
}

// Returns {name, times, nextPrayer:{name,timeStr,remainingMs}} using stored settings.
export async function getTodayTimes() {
  const settings = getLocationSettings();
  let lat, lng, tz, label;
  if (settings.mode === "gps" && settings.lat != null) {
    lat = settings.lat; lng = settings.lng; tz = -new Date().getTimezoneOffset() / 60;
    label = "আপনার বর্তমান অবস্থান";
  } else {
    const city = CITIES[settings.city] || CITIES["Dhaka,BD"];
    lat = city.lat; lng = city.lng; tz = city.tz; label = city.name;
  }
  const times = calculateTimes({ lat, lng, tz, method: settings.method, asrMethod: settings.asrMethod });
  return { label, times, settings };
}

const PRAYER_ORDER = ["fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha"];
const PRAYER_LABELS_BN = { fajr: "ফজর", sunrise: "সূর্যোদয়", dhuhr: "যুহর", asr: "আসর", maghrib: "মাগরিব", isha: "ইশা" };

export function nextPrayer(times) {
  const now = new Date();
  const nowHours = now.getHours() + now.getMinutes() / 60 + now.getSeconds() / 3600;
  const order = PRAYER_ORDER.filter((p) => p !== "sunrise");
  for (const key of order) {
    const h = times.raw[key];
    if (h != null && h > nowHours) {
      return { key, label: PRAYER_LABELS_BN[key], timeStr: times[key], raw: h };
    }
  }
  // all passed — next is tomorrow's Fajr
  return { key: "fajr", label: PRAYER_LABELS_BN.fajr, timeStr: times.fajr, raw: times.raw.fajr + 24, tomorrow: true };
}

export function labelsBn() { return PRAYER_LABELS_BN; }
export function order() { return PRAYER_ORDER.filter((p) => p !== "sunrise"); }
