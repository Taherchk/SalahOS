// data.js — loads the structured content JSON files (data/*.json).
// Service worker caches these for offline use; here we just fetch + memoize.
const cache = {};

async function load(name) {
  if (cache[name]) return cache[name];
  try {
    const res = await fetch(`data/${name}.json`, { cache: "force-cache" });
    if (!res.ok) throw new Error("Bad response " + res.status);
    const json = await res.json();
    cache[name] = json;
    return json;
  } catch (e) {
    console.warn(`SalahOS: could not load data/${name}.json`, e);
    return name === "salah_steps" ? {} : [];
  }
}

export const getSurahs = () => load("surahs");
export const getSalahRecitations = () => load("salah_recitations");
export const getDuas = () => load("duas");
export const getDhikr = () => load("dhikr");
export const getSalahSteps = () => load("salah_steps");
export const getFiqh = () => load("fiqh");
export const getQuiz = () => load("quiz");

export async function findSurah(id) {
  const all = await getSurahs();
  return all.find((s) => s.id === Number(id));
}
export async function findRecitation(id) {
  const all = await getSalahRecitations();
  return all.find((r) => r.id === id);
}

export async function preloadAll() {
  await Promise.all([
    getSurahs(), getSalahRecitations(), getDuas(), getDhikr(),
    getSalahSteps(), getFiqh(), getQuiz(),
  ]);
}
