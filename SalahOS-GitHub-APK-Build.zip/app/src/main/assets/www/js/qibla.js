// qibla.js — Qibla bearing (great-circle to the Kaaba) + optional compass via device sensors.
import { CITIES, getLocationSettings, setLocationSettings, requestGeolocation } from "./prayer-time.js";
import { esc, toast } from "./ui.js";

const KAABA = { lat: 21.4225, lng: 39.8262 };
const rad = (d) => (d * Math.PI) / 180;
const deg = (r) => (r * 180) / Math.PI;

export function qiblaBearing(lat, lng) {
  const dl = rad(KAABA.lng - lng);
  const p1 = rad(lat), p2 = rad(KAABA.lat);
  const y = Math.sin(dl) * Math.cos(p2);
  const x = Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl);
  return (deg(Math.atan2(y, x)) + 360) % 360;
}

function currentCoords() {
  const s = getLocationSettings();
  if (s.mode === "gps" && s.lat != null) return { lat: s.lat, lng: s.lng, label: "আপনার বর্তমান অবস্থান" };
  const c = CITIES[s.city] || CITIES["Dhaka,BD"];
  return { lat: c.lat, lng: c.lng, label: c.name };
}

let stopSensor = null;
export async function renderQibla(container) {
  if (stopSensor) { stopSensor(); stopSensor = null; }
  const c = currentCoords();
  const bearing = qiblaBearing(c.lat, c.lng);
  container.innerHTML = `
    <div class="card text-center">
      <p class="muted small">${esc(c.label)} থেকে কিবলার দিক</p>
      <div style="font-size:2rem;font-weight:800;color:var(--emerald-light);">${bearing.toFixed(1)}°</div>
      <p class="muted small">উত্তর দিক থেকে ঘড়ির কাঁটার দিকে</p>
      <div id="compass" style="position:relative;width:240px;height:240px;margin:14px auto;border-radius:50%;border:3px solid var(--emerald);background:var(--card-bg);">
        <div style="position:absolute;top:4px;left:50%;transform:translateX(-50%);font-weight:700;">N</div>
        <div id="needle" style="position:absolute;inset:0;transition:transform .15s linear;">
          <div style="position:absolute;left:50%;top:14px;width:0;height:0;margin-left:-14px;border-left:14px solid transparent;border-right:14px solid transparent;border-bottom:90px solid var(--gold);"></div>
          <div style="position:absolute;left:50%;top:6px;margin-left:-10px;font-size:1.3rem;">🕋</div>
        </div>
      </div>
      <p id="compassMsg" class="muted small">কম্পাস সেন্সর যাচাই করা হচ্ছে...</p>
      <button class="btn btn-outline btn-block" id="enableSensor">🧭 কম্পাস চালু করুন</button>
      <button class="btn btn-ghost btn-block mt-8" id="useGps">📍 বর্তমান অবস্থান ব্যবহার করুন</button>
    </div>
    <div class="card"><p class="muted small">⚠️ ফোনের কম্পাস সেন্সর ধাতব বস্তু বা চুম্বকের কাছে ভুল দিক দিতে পারে। ফোন সমতলে ধরে ৮-এর মতো ঘুরিয়ে ক্যালিব্রেট করুন। নিশ্চিত হতে স্থানীয় মসজিদের দিকনির্দেশনার সাথে মিলিয়ে নিন।</p></div>`;
  const needle = container.querySelector("#needle");
  const msg = container.querySelector("#compassMsg");
  needle.style.transform = `rotate(${bearing}deg)`;
  let gotEvent = false;
  function onOrient(e) {
    let heading = null;
    if (typeof e.webkitCompassHeading === "number") heading = e.webkitCompassHeading;
    else if (e.alpha != null && (e.absolute || e.type === "deviceorientationabsolute")) heading = (360 - e.alpha) % 360;
    if (heading == null) return;
    gotEvent = true;
    needle.style.transform = `rotate(${(bearing - heading + 360) % 360}deg)`;
    msg.textContent = "কম্পাস চালু — 🕋 চিহ্নের দিকে ঘুরে দাঁড়ান।";
  }
  function start() {
    window.addEventListener("deviceorientationabsolute", onOrient, true);
    window.addEventListener("deviceorientation", onOrient, true);
    stopSensor = () => {
      window.removeEventListener("deviceorientationabsolute", onOrient, true);
      window.removeEventListener("deviceorientation", onOrient, true);
    };
    setTimeout(() => { if (!gotEvent) msg.textContent = `কম্পাস সেন্সর পাওয়া যায়নি। উত্তর দিক থেকে ${bearing.toFixed(0)}° ডানে ঘুরলে কিবলা।`; }, 2000);
  }
  container.querySelector("#enableSensor").addEventListener("click", async () => {
    try {
      if (typeof DeviceOrientationEvent !== "undefined" && typeof DeviceOrientationEvent.requestPermission === "function") {
        const p = await DeviceOrientationEvent.requestPermission();
        if (p !== "granted") { toast("সেন্সরের অনুমতি দেওয়া হয়নি।"); return; }
      }
    } catch (e) { /* ignore */ }
    if (stopSensor) stopSensor();
    start();
  });
  container.querySelector("#useGps").addEventListener("click", async () => {
    try {
      const pos = await requestGeolocation();
      const l = getLocationSettings(); l.mode = "gps"; l.lat = pos.lat; l.lng = pos.lng; setLocationSettings(l);
      renderQibla(container);
    } catch (e) { toast("অবস্থান পাওয়া যায়নি। সেটিংস থেকে শহর নির্বাচন করুন।"); }
  });
  start();
}
