// dhikr.js — Dhikr library + Tasbih counter.
import { getDhikr } from "./data.js";
import { getItem, setItem, KEYS } from "./storage.js";
import { esc, skeletonBlock, toast, bindNavClicks } from "./ui.js";
import { isFavorite, toggleFavorite } from "./favorites.js";

export async function getDailyDhikr() {
  const items = await getDhikr();
  if (!items.length) return null;
  const day = Math.floor(Date.now() / 86400000);
  return items[day % items.length];
}

export async function renderDhikrLibrary(container) {
  container.innerHTML = skeletonBlock(6);
  const items = await getDhikr();
  const groups = {};
  items.forEach((d) => { (groups[d.category] = groups[d.category] || []).push(d); });
  container.innerHTML = `
    <div class="card"><button class="btn btn-gold btn-block" data-nav="tasbih">📿 ডিজিটাল তাসবীহ খুলুন</button></div>
    ${Object.keys(groups).map((cat) => `
      <div class="card">
        <h3 style="margin-top:0;">${esc(cat)}</h3>
        ${groups[cat].map((d) => dhikrBlock(d)).join("")}
      </div>
    `).join("")}
  `;
  container.querySelectorAll("[data-fav]").forEach((btn) => {
    btn.addEventListener("click", () => {
      toggleFavorite("dhikr", btn.dataset.fav, { title: btn.dataset.title });
      btn.textContent = isFavorite("dhikr", btn.dataset.fav) ? "❤️" : "🤍";
    });
  });
  container.querySelectorAll("[data-count]").forEach((btn) => {
    btn.addEventListener("click", () => {
      window.dispatchEvent(new CustomEvent("salahos:navigate", { detail: { route: "tasbih", params: { dhikr: btn.dataset.count } } }));
    });
  });
  bindNavClicks(container);
}

function dhikrBlock(d) {
  const fav = isFavorite("dhikr", d.id);
  return `<div class="ayah-block">
    <div class="card-row">
      <strong>${esc(d.titleBn)}</strong>
      <button class="btn btn-ghost btn-sm" data-fav="${d.id}" data-title="${esc(d.titleBn)}">${fav ? "❤️" : "🤍"}</button>
    </div>
    <div class="arabic" style="margin-top:8px;">${esc(d.arabic)}</div>
    <div class="translit">${esc(d.pronunciationBn)}</div>
    <div class="meaning">${esc(d.meaningBn)}</div>
    <p class="muted small">সূত্রঃ ${esc(d.source || "—")} ${d.recommendedCount ? `· প্রস্তাবিত সংখ্যাঃ ${d.recommendedCount}` : ""}</p>
    ${d.recommendedCount ? `<button class="btn btn-outline btn-sm" data-count="${d.id}">📿 তাসবীহ শুরু করুন</button>` : ""}
  </div>`;
}

// ---- Tasbih Counter ----
function getTasbihState() {
  return getItem("tasbihState", { count: 0, target: 33, history: [] });
}
function saveTasbihState(s) { setItem("tasbihState", s); }

export async function renderTasbih(container, params) {
  let state = getTasbihState();
  let dhikrLabel = "তাসবীহ";
  if (params.dhikr) {
    const items = await getDhikr();
    const d = items.find((x) => x.id === params.dhikr);
    if (d) { dhikrLabel = d.titleBn; state.target = d.recommendedCount || 33; }
  }
  let lastTap = 0;

  function draw() {
    container.innerHTML = `
      <div class="card text-center">
        <h3>${esc(dhikrLabel)}</h3>
        <div class="tasbih-wrap">
          <div class="tasbih-count" id="countDisplay">${state.count}</div>
          <div class="muted">লক্ষ্যঃ ${state.target}</div>
          <button class="tasbih-btn" id="tapBtn">ট্যাপ করুন</button>
          <div class="flex gap-8 mt-8">
            <button class="btn btn-ghost btn-sm" data-preset="33">৩৩</button>
            <button class="btn btn-ghost btn-sm" data-preset="34">৩৪</button>
            <button class="btn btn-ghost btn-sm" data-preset="99">৯৯</button>
            <button class="btn btn-ghost btn-sm" id="customPreset">কাস্টম</button>
          </div>
          <div class="flex gap-8 mt-8">
            <button class="btn btn-outline btn-sm" id="undoBtn">↩️ আনডু</button>
            <button class="btn btn-outline btn-sm" id="resetBtn">🔄 রিসেট</button>
            <button class="btn btn-outline btn-sm" id="soundBtn">${state.sound === false ? "🔇" : "🔊"}</button>
            <button class="btn btn-outline btn-sm" id="vibBtn">${state.vibrate === false ? "📴" : "📳"}</button>
          </div>
        </div>
      </div>
    `;
    const countEl = container.querySelector("#countDisplay");
    container.querySelector("#tapBtn").addEventListener("click", () => {
      const now = Date.now();
      if (now - lastTap < 80) return; // debounce accidental double taps
      lastTap = now;
      state.count++;
      saveTasbihState(state);
      countEl.textContent = state.count;
      countEl.classList.remove("pulse"); void countEl.offsetWidth; countEl.classList.add("pulse");
      if (state.vibrate !== false && navigator.vibrate) { try { navigator.vibrate(15); } catch (e) {} }
      if (state.count === state.target) {
        toast(`✅ লক্ষ্য (${state.target}) সম্পন্ন হয়েছে!`);
        if (state.vibrate !== false && navigator.vibrate) { try { navigator.vibrate([40, 40, 40]); } catch (e) {} }
      }
    });
    container.querySelectorAll("[data-preset]").forEach((b) => b.addEventListener("click", () => {
      state.target = Number(b.dataset.preset); saveTasbihState(state); draw();
    }));
    container.querySelector("#customPreset").addEventListener("click", () => {
      const v = prompt("কাস্টম লক্ষ্য সংখ্যা লিখুনঃ", String(state.target));
      const n = parseInt(v, 10);
      if (n > 0) { state.target = n; saveTasbihState(state); draw(); }
    });
    container.querySelector("#undoBtn").addEventListener("click", () => {
      if (state.count > 0) state.count--; saveTasbihState(state); countEl.textContent = state.count;
    });
    container.querySelector("#resetBtn").addEventListener("click", () => {
      state.history.push({ count: state.count, at: Date.now() });
      state.count = 0; saveTasbihState(state); draw();
    });
    container.querySelector("#soundBtn").addEventListener("click", () => { state.sound = state.sound === false ? true : false; saveTasbihState(state); draw(); });
    container.querySelector("#vibBtn").addEventListener("click", () => { state.vibrate = state.vibrate === false ? true : false; saveTasbihState(state); draw(); });
    bindNavClicks(container);
  }
  draw();
}
