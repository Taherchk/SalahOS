// fiqh.js — "Prayer Notes" showing scholarly/madhhab differences neutrally.
import { getFiqh } from "./data.js";
import { esc, bindNavClicks, skeletonBlock } from "./ui.js";

const MADHHAB_LABELS = { hanafi: "হানাফি", shafii: "শাফিঈ", maliki: "মালিকি", hanbali: "হাম্বলি" };

export async function renderFiqh(container) {
  container.innerHTML = skeletonBlock(4);
  const notes = await getFiqh();
  container.innerHTML = `
    <div class="card"><p class="muted small">⚠️ ব্যক্তিগত ইবাদতের নির্দিষ্ট বিষয়ে একজন যোগ্য স্থানীয় আলেমের পরামর্শ নিন। এই নোটগুলো শুধুমাত্র শিক্ষামূলক সহায়তা।</p></div>
    ${notes.map((n) => `
      <div class="card">
        <h3 style="margin-top:0;">${esc(n.titleBn)}</h3>
        <p>${esc(n.bodyBn)}</p>
        <p><span class="badge badge-scholarly">বিভিন্ন ফিকহি মতামত / Scholarly Difference</span></p>
        ${Object.entries(n.madhhabViews || {}).map(([k, v]) => `
          <div class="ayah-block">
            <strong>${esc(MADHHAB_LABELS[k] || k)}</strong>
            <p class="small" style="margin:4px 0 0;">${esc(v)}</p>
          </div>
        `).join("")}
        <p class="muted small mt-8">${esc(n.note || "")}</p>
      </div>
    `).join("")}
  `;
  bindNavClicks(container);
}
