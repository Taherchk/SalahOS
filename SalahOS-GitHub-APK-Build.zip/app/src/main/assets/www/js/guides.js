// guides.js — Wudu guide and Adhan page.
import { esc, skeletonBlock, bindNavClicks } from "./ui.js";

let cache = null;
async function load() {
  if (cache) return cache;
  try {
    const r = await fetch("data/guides.json", { cache: "force-cache" });
    cache = await r.json();
  } catch (e) { cache = {}; }
  return cache;
}

export async function renderWudu(container) {
  container.innerHTML = skeletonBlock(5);
  const g = (await load()).wudu;
  if (!g) { container.innerHTML = `<div class="card">তথ্য লোড করা যায়নি।</div>`; return; }
  container.innerHTML = `
    <div class="card"><h3 style="margin-top:0;">${esc(g.titleBn)}</h3>
      ${g.steps.map((s) => `<div class="ayah-block"><span class="ayah-num">${s.n}</span><strong> ${esc(s.titleBn)}</strong><p style="margin:6px 0 0;">${esc(s.bodyBn)}</p></div>`).join("")}
      <p class="small"><span class="badge badge-scholarly">বিভিন্ন ফিকহি মতামত</span> ${esc(g.scholarlyDifference)}</p>
    </div>
    <div class="card"><h3 style="margin-top:0;">${esc(g.duaAfter.titleBn)}</h3>
      <div class="arabic">${esc(g.duaAfter.arabic)}</div>
      <div class="translit">${esc(g.duaAfter.pronunciationBn)}</div>
      <div class="meaning">${esc(g.duaAfter.meaningBn)}</div>
      <p class="muted small">সূত্রঃ ${esc(g.duaAfter.source)}</p>
    </div>`;
  bindNavClicks(container);
}

export async function renderAdhan(container) {
  container.innerHTML = skeletonBlock(5);
  const g = (await load()).adhan;
  if (!g) { container.innerHTML = `<div class="card">তথ্য লোড করা যায়নি।</div>`; return; }
  const block = (l) => `<div class="ayah-block"><div class="arabic">${esc(l.arabic)}</div><div class="translit">${esc(l.pronunciationBn)}</div><div class="meaning">${esc(l.meaningBn)}</div></div>`;
  container.innerHTML = `
    <div class="card"><h3 style="margin-top:0;">${esc(g.titleBn)}</h3>${g.lines.map(block).join("")}
      <h4>শুধু ফজরের আযানে অতিরিক্ত</h4>${block(g.fajrExtra)}
      <p class="small"><span class="badge badge-scholarly">বিভিন্ন ফিকহি মতামত</span> ${esc(g.scholarlyDifference)}</p>
    </div>`;
  bindNavClicks(container);
}
