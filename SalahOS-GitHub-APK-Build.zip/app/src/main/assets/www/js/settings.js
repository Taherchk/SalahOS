// settings.js — the Settings page and data export/import/reset logic.
import { getItem, setItem, KEYS, allKeys, removeItem, clearAll } from "./storage.js";
import { esc, toast, bindNavClicks } from "./ui.js";
import { getLocationSettings, setLocationSettings, requestGeolocation, CITIES, METHODS } from "./prayer-time.js";
import * as notif from "./notifications.js";

export function getSettings() {
  return getItem(KEYS.SETTINGS, { reducedMotion: false, reducedEffects: false, haptic: true, translationLang: "bn" });
}
export function saveSettings(s) { setItem(KEYS.SETTINGS, s); }

export function applyTheme(theme) {
  const root = document.documentElement;
  if (theme === "light" || theme === "dark") root.setAttribute("data-theme", theme);
  else root.removeAttribute("data-theme");
  setItem(KEYS.THEME, theme);
}

export function applyArabicSize(size) {
  document.documentElement.setAttribute("data-font-size", size);
  setItem(KEYS.ARABIC_SIZE, size);
}

export async function renderSettings(container) {
  const settings = getSettings();
  const theme = getItem(KEYS.THEME, "system");
  const arabicSize = getItem(KEYS.ARABIC_SIZE, "medium");
  const loc = getLocationSettings();
  const notifPrefs = notif.getPrefs();

  container.innerHTML = `
    <div class="card">
      <h3 style="margin-top:0;">চেহারা</h3>
      <label>থিম</label>
      <select id="themeSel">
        <option value="system" ${theme === "system" ? "selected" : ""}>সিস্টেম অনুযায়ী</option>
        <option value="light" ${theme === "light" ? "selected" : ""}>লাইট</option>
        <option value="dark" ${theme === "dark" ? "selected" : ""}>ডার্ক</option>
      </select>
      <label class="mt-8">আরবি ফন্টের আকার</label>
      <select id="arabicSizeSel">
        <option value="small" ${arabicSize === "small" ? "selected" : ""}>ছোট</option>
        <option value="medium" ${arabicSize === "medium" ? "selected" : ""}>মাঝারি</option>
        <option value="large" ${arabicSize === "large" ? "selected" : ""}>বড়</option>
        <option value="xl" ${arabicSize === "xl" ? "selected" : ""}>অতিরিক্ত বড়</option>
      </select>
      <label class="mt-8 flex gap-8" style="align-items:center;"><input type="checkbox" id="reducedMotion" ${settings.reducedMotion ? "checked" : ""}> অ্যানিমেশন কমান (Reduced Motion)</label>
      <label class="flex gap-8" style="align-items:center;"><input type="checkbox" id="hapticChk" ${settings.haptic !== false ? "checked" : ""}> হ্যাপটিক ফিডব্যাক (ভাইব্রেশন)</label>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">নামাজের সময় গণনা</h3>
      <label>পদ্ধতি</label>
      <select id="methodSel">
        ${Object.keys(METHODS).map((m) => `<option value="${m}" ${loc.method === m ? "selected" : ""}>${METHODS[m].name}</option>`).join("")}
      </select>
      <label class="mt-8">আসরের হিসাব</label>
      <select id="asrSel">
        <option value="Standard" ${loc.asrMethod === "Standard" ? "selected" : ""}>Standard (Shafi'i/Maliki/Hanbali)</option>
        <option value="Hanafi" ${loc.asrMethod === "Hanafi" ? "selected" : ""}>Hanafi</option>
      </select>
      <label class="mt-8">অবস্থান</label>
      <select id="citySel">
        ${Object.entries(CITIES).map(([k, c]) => `<option value="${k}" ${loc.mode !== "gps" && loc.city === k ? "selected" : ""}>${esc(c.name)}</option>`).join("")}
      </select>
      <button class="btn btn-outline btn-block mt-8" id="useGpsBtn">📍 বর্তমান অবস্থান ব্যবহার করুন</button>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">নোটিফিকেশন</h3>
      <label class="flex gap-8" style="align-items:center;"><input type="checkbox" id="notifEnabled" ${notifPrefs.enabled ? "checked" : ""}> নামাজের রিমাইন্ডার চালু করুন</label>
      <p class="muted small">রিমাইন্ডার কাজ করতে ব্রাউজার নোটিফিকেশন অনুমতি প্রয়োজন, এবং অ্যাপ/ট্যাব খোলা থাকা অবস্থায় সক্রিয় থাকে।</p>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">ডেটা ব্যবস্থাপনা</h3>
      <button class="btn btn-outline btn-block" id="exportBtn">⬇️ ডেটা এক্সপোর্ট করুন (JSON)</button>
      <input type="file" id="importFile" accept="application/json" style="display:none;">
      <button class="btn btn-outline btn-block mt-8" id="importBtn">⬆️ ডেটা ইমপোর্ট করুন</button>
      <button class="btn btn-danger btn-block mt-8" id="resetBtn">🗑️ সব ডেটা রিসেট করুন</button>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">সম্পর্কে</h3>
      <p><strong>SalahOS</strong> — v0.1.0 (ডেমো)</p>
      <p class="small">উদ্দেশ্যঃ সালাহ শেখা ও অনুশীলনে সহায়তা করা।</p>
      <p class="small">গোপনীয়তাঃ কোনো অ্যাকাউন্ট/লগইন প্রয়োজন নেই, কোনো বিজ্ঞাপন নেই, আপনার ব্যক্তিগত তথ্য শুধুমাত্র আপনার ডিভাইসে সংরক্ষিত হয় এবং কোনো সার্ভারে পাঠানো হয় না।</p>
      <p class="small">কনটেন্ট যাচাইঃ আরবি পাঠ্য, উচ্চারণ ও অর্থ প্রতিষ্ঠিত সূত্র থেকে নেওয়া হয়েছে; ফিকহি মতভেদের ক্ষেত্রে একাধিক মাযহাবের অভিমত দেখানো হয়েছে।</p>
      <p class="small" style="font-style:italic;">এই অ্যাপটি একটি শিক্ষা সহায়ক মাত্র এবং যোগ্য ইসলামী বিদ্বানদের স্থলাভিষিক্ত নয়।</p>
    </div>
  `;

  container.querySelector("#themeSel").addEventListener("change", (e) => applyTheme(e.target.value));
  container.querySelector("#arabicSizeSel").addEventListener("change", (e) => applyArabicSize(e.target.value));
  container.querySelector("#reducedMotion").addEventListener("change", (e) => {
    settings.reducedMotion = e.target.checked;
    document.body.classList.toggle("reduced-motion", e.target.checked);
    saveSettings(settings);
  });
  container.querySelector("#hapticChk").addEventListener("change", (e) => { settings.haptic = e.target.checked; saveSettings(settings); });

  container.querySelector("#methodSel").addEventListener("change", (e) => { const l = getLocationSettings(); l.method = e.target.value; setLocationSettings(l); toast("সংরক্ষিত হয়েছে"); });
  container.querySelector("#asrSel").addEventListener("change", (e) => { const l = getLocationSettings(); l.asrMethod = e.target.value; setLocationSettings(l); toast("সংরক্ষিত হয়েছে"); });
  container.querySelector("#citySel").addEventListener("change", (e) => { const l = getLocationSettings(); l.mode = "manual"; l.city = e.target.value; setLocationSettings(l); toast("সংরক্ষিত হয়েছে"); });
  container.querySelector("#useGpsBtn").addEventListener("click", async () => {
    try {
      const pos = await requestGeolocation();
      const l = getLocationSettings();
      l.mode = "gps"; l.lat = pos.lat; l.lng = pos.lng;
      setLocationSettings(l);
      toast("অবস্থান আপডেট হয়েছে");
    } catch (e) {
      toast("অবস্থান পাওয়া যায়নি। অনুমতি দিন অথবা শহর নির্বাচন করুন।");
    }
  });

  container.querySelector("#notifEnabled").addEventListener("change", async (e) => {
    const prefs = notif.getPrefs();
    if (e.target.checked) {
      const perm = await notif.requestPermission();
      if (perm !== "granted") { e.target.checked = false; toast("নোটিফিকেশন অনুমতি দেওয়া হয়নি।"); return; }
    }
    prefs.enabled = e.target.checked;
    notif.setPrefs(prefs);
  });

  container.querySelector("#exportBtn").addEventListener("click", exportData);
  container.querySelector("#importBtn").addEventListener("click", () => container.querySelector("#importFile").click());
  container.querySelector("#importFile").addEventListener("change", (e) => importData(e.target.files[0]));
  container.querySelector("#resetBtn").addEventListener("click", () => {
    if (confirm("এটি স্থায়ীভাবে আপনার লোকাল শেখার অগ্রগতি, পছন্দসই আইটেম, নোট এবং সেটিংস মুছে ফেলবে। আপনি কি নিশ্চিত?")) {
      clearAll();
      toast("সব ডেটা রিসেট হয়েছে। পাতাটি পুনরায় লোড হবে।");
      setTimeout(() => location.reload(), 1200);
    }
  });

  bindNavClicks(container);
}

function exportData() {
  const data = {};
  allKeys().forEach((k) => { data[k] = getItem(k); });
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = `salahos-backup-${Date.now()}.json`;
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
  toast("ব্যাকআপ ডাউনলোড হয়েছে");
}

function importData(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const parsed = JSON.parse(reader.result);
      if (typeof parsed !== "object" || parsed === null) throw new Error("invalid");
      if (!confirm("এই ব্যাকআপ ইমপোর্ট করলে আপনার বর্তমান লোকাল ডেটা প্রতিস্থাপিত হবে। চালিয়ে যাবেন?")) return;
      Object.entries(parsed).forEach(([k, v]) => setItem(k, v));
      toast("ইমপোর্ট সম্পন্ন হয়েছে। পাতাটি পুনরায় লোড হবে।");
      setTimeout(() => location.reload(), 1200);
    } catch (e) {
      toast("ফাইলটি বৈধ ব্যাকআপ নয়।");
    }
  };
  reader.readAsText(file);
}
