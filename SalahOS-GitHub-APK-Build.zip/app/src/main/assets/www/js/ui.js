// ui.js — shared small UI helpers used across all views.
let toastTimer = null;
export function toast(msg, ms = 2200) {
  const el = document.getElementById("toast");
  if (!el) return;
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), ms);
}

export function esc(str) {
  if (str == null) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

export function confirmDialog(message, onYes, onNo) {
  const yes = window.confirm(message);
  if (yes) onYes && onYes();
  else onNo && onNo();
}

export function skeletonBlock(count = 3) {
  let html = "";
  for (let i = 0; i < count; i++) html += `<div class="skeleton" style="width:${70 + (i % 3) * 10}%"></div>`;
  return html;
}

export function emptyState(icon, title, subtitle, actionLabel, actionRoute) {
  return `<div class="empty-state">
    <span class="big-icon">${icon}</span>
    <h3>${esc(title)}</h3>
    <p class="muted">${esc(subtitle)}</p>
    ${actionLabel ? `<button class="btn btn-primary" data-nav="${actionRoute}">${esc(actionLabel)}</button>` : ""}
  </div>`;
}

export function card(innerHtml, extraClass = "") {
  return `<div class="card ${extraClass}">${innerHtml}</div>`;
}

export function progressBar(percent) {
  const p = Math.max(0, Math.min(100, Math.round(percent)));
  return `<div class="progress-bar"><span style="width:${p}%"></span></div>`;
}

export function fmtPercent(n) {
  return `${Math.round(n)}%`;
}

export function applyReducedMotion() {
  const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  document.body.classList.toggle("reduced-motion", !!reduce);
}

// Bind any element with data-nav="route" to navigate via a custom event,
// so individual view modules don't need to import router directly (avoids circular imports).
export function bindNavClicks(root = document) {
  root.querySelectorAll("[data-nav]").forEach((el) => {
    el.addEventListener("click", () => {
      window.dispatchEvent(new CustomEvent("salahos:navigate", { detail: { route: el.getAttribute("data-nav") } }));
    });
  });
}
