// notifications.js — Notification API wrapper. Never throws if unsupported.
import { getItem, setItem } from "./storage.js";
import { toast } from "./ui.js";

const KEY = "notificationPrefs";
let scheduled = [];

export function isSupported() { return typeof Notification !== "undefined"; }

export async function requestPermission() {
  if (!isSupported()) { toast("আপনার ব্রাউজারে নোটিফিকেশন সমর্থিত নয়।"); return "unsupported"; }
  try {
    const perm = await Notification.requestPermission();
    return perm;
  } catch (e) {
    return "denied";
  }
}

export function getPrefs() { return getItem(KEY, { enabled: false, offsets: [10] }); }
export function setPrefs(p) { setItem(KEY, p); }

function notify(title, body) {
  if (!isSupported() || Notification.permission !== "granted") return;
  try { new Notification(title, { body, icon: "assets/icons/icon.svg" }); } catch (e) { /* ignore */ }
}

// Schedules in-session reminders for today's remaining prayers (while the app/tab stays open).
// True background push notifications would require a server + push subscription, which this
// offline-first, backend-free app intentionally does not use.
export function scheduleTodayReminders(times, labelsBn) {
  scheduled.forEach((t) => clearTimeout(t));
  scheduled = [];
  const prefs = getPrefs();
  if (!prefs.enabled || !isSupported() || Notification.permission !== "granted") return;
  const now = new Date();
  Object.entries(times.raw || {}).forEach(([key, hourFloat]) => {
    if (key === "sunrise" || hourFloat == null) return;
    const target = new Date(now); target.setHours(0, 0, 0, 0);
    target.setMilliseconds(hourFloat * 3600000);
    prefs.offsets.forEach((offsetMin) => {
      const fireAt = new Date(target.getTime() - offsetMin * 60000);
      const delay = fireAt - now;
      if (delay > 0 && delay < 24 * 3600000) {
        const id = setTimeout(() => {
          notify("SalahOS — নামাজের সময় কাছে", offsetMin === 0 ? `${labelsBn[key]}-এর সময় হয়েছে।` : `${labelsBn[key]}-এর ${offsetMin} মিনিট বাকি।`);
        }, delay);
        scheduled.push(id);
      }
    });
  });
}
