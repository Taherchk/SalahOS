// surah.js — Surah library + reader.
import { getSurahs, findSurah } from "./data.js";
import { esc, skeletonBlock, emptyState, bindNavClicks } from "./ui.js";
import { isFavorite, toggleFavorite } from "./favorites.js";
import { getProgress } from "./memorization.js";
import * as audio from "./audio.js";

export async function renderSurahList(container, params) {
  if (!params || !params._filter) { delete container.dataset.q; container.innerHTML = skeletonBlock(5); }
  const surahs = await getSurahs();
  if (!surahs.length) {
    container.innerHTML = emptyState("📖", "সূরা লোড করা যায়নি", "ডেটা ফাইল পাওয়া যায়নি বা অফলাইনে ক্যাশ হয়নি।", "হোম", "home");
    bindNavClicks(container);
    return;
  }
  const q = (container.dataset.q || "").trim().toLowerCase();
  const shown = surahs.filter((s) => !q || (s.nameBangla + " " + s.nameEnglish + " " + s.nameArabic).toLowerCase().includes(q));
  container.innerHTML = `
    <div class="card" style="margin-bottom:10px;">
      <p class="muted" style="margin:0 0 8px;">সালাতে ও দৈনন্দিন আমলে ব্যবহৃত গুরুত্বপূর্ণ সূরা ও আয়াত (${surahs.length}টি)। আরবি পাঠ ও অনুবাদ আলেমের যাচাই বাকি।</p>
      <input type="search" id="surahFilter" placeholder="সূরা খুঁজুন..." value="${esc(container.dataset.q || "")}">
    </div>
    ${shown.map((s) => {
      const prog = getProgress("surah", s.id);
      return `<div class="list-item" data-nav-surah="${s.id}">
        <div>
          <div style="font-weight:700;">${esc(s.label || s.id)}. ${esc(s.nameBangla)} <span class="muted">(${esc(s.nameEnglish)})</span></div>
          <div class="muted small">${s.ayahCount} আয়াত ${prog ? `· মুখস্থ অগ্রগতি ${prog.percent}%` : ""}</div>
        </div>
        <div class="arabic" style="font-size:1.1rem;">${esc(s.nameArabic)}</div>
      </div>`;
    }).join("")}
  `;
  const filter = container.querySelector("#surahFilter");
  if (filter) filter.addEventListener("input", () => {
    container.dataset.q = filter.value;
    renderSurahList(container, { _filter: true }).then(() => { const f = container.querySelector("#surahFilter"); if (f) { f.focus(); f.setSelectionRange(f.value.length, f.value.length); } });
  });
  container.querySelectorAll("[data-nav-surah]").forEach((el) => {
    el.addEventListener("click", () => {
      window.dispatchEvent(new CustomEvent("salahos:navigate", { detail: { route: "surah-reader", params: { id: el.dataset.navSurah } } }));
    });
  });
  bindNavClicks(container);
}

const MODES = ["all", "arabic", "arabic_translit", "arabic_translation"];
const MODE_LABELS = { all: "সব", arabic: "শুধু আরবি", arabic_translit: "আরবি + উচ্চারণ", arabic_translation: "আরবি + অর্থ" };

export async function renderSurahReader(container, params) {
  const id = params.id;
  container.innerHTML = skeletonBlock(4);
  const surah = await findSurah(id);
  if (!surah) {
    container.innerHTML = emptyState("⚠️", "সূরা পাওয়া যায়নি", "", "সূরা তালিকা", "surahs");
    bindNavClicks(container);
    return;
  }
  let mode = "all";
  const fav = isFavorite("surah", surah.id);

  function draw() {
    container.innerHTML = `
      <div class="card">
        <div class="card-row">
          <div>
            <h2 style="margin:0;">${esc(surah.nameBangla)} <span class="muted small">(${esc(surah.nameEnglish)})</span></h2>
            <div class="muted small">${surah.ayahCount} আয়াত ${surah.verified ? '<span class="badge">✓ যাচাইকৃত</span>' : '<span class="badge badge-scholarly">আলেম-যাচাই বাকি</span>'}</div>
          </div>
          <button class="btn btn-ghost btn-sm" id="favBtn">${fav ? "❤️" : "🤍"}</button>
        </div>
        <div class="pill-row" style="margin-top:12px;">
          ${MODES.map((m) => `<button class="pill ${mode === m ? "active" : ""}" data-mode="${m}">${MODE_LABELS[m]}</button>`).join("")}
        </div>
      </div>
      <div class="card">
        ${surah.ayahs.map((a) => renderAyah(a, mode, surah.id)).join("")}
      </div>
      <div class="card">
        <button class="btn btn-primary btn-block" data-nav="memorization?type=surah&id=${surah.id}">🧠 মুখস্থ অনুশীলন শুরু করুন</button>
      </div>
    `;
    container.querySelectorAll("[data-mode]").forEach((b) => b.addEventListener("click", () => { mode = b.dataset.mode; draw(); }));
    container.querySelector("#favBtn").addEventListener("click", () => {
      toggleFavorite("surah", surah.id, { title: surah.nameBangla });
      draw();
    });
    surah.ayahs.forEach((a) => {
      const id2 = `ayah-${surah.id}-${a.number}`;
      audio.bindAudioControls(container, a.audio, id2);
    });
    bindNavClicks(container);
  }
  draw();
}

function renderAyah(a, mode, surahId) {
  const showArabic = true;
  const showTranslit = mode === "all" || mode === "arabic_translit";
  const showMeaning = mode === "all" || mode === "arabic_translation";
  const id2 = `ayah-${surahId}-${a.number}`;
  return `<div class="ayah-block">
    <span class="ayah-num">${a.number}</span>
    ${showArabic ? `<div class="arabic">${esc(a.arabic)}</div>` : ""}
    ${showTranslit ? `<div class="translit">${esc(a.transliteration)}</div>` : ""}
    ${showMeaning ? `<div class="meaning">${esc(a.translationBn)}</div>` : ""}
    ${audio.audioControlsHtml(id2)}
  </div>`;
}
