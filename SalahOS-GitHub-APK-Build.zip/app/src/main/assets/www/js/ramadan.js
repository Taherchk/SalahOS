// ramadan.js — optional Ramadan companion section.
import { getTodayTimes } from "./prayer-time.js";
import { getItem, setItem } from "./storage.js";
import { esc, bindNavClicks } from "./ui.js";
import { getDailyDua } from "./dua.js";

const CHECKLIST_ITEMS = [
  "ফজরের আগে সেহরি করা", "৫ ওয়াক্ত সালাত আদায় করা", "তারাবীহ পড়া",
  "কুরআন তিলাওয়াত করা", "ইফতারের সময় দুআ পড়া", "সাদাকাহ/দান করা",
];

function getChecklistState(dateKey) {
  return getItem("ramadanChecklist:" + dateKey, {});
}
function setChecklistState(dateKey, state) {
  setItem("ramadanChecklist:" + dateKey, state);
}

export async function renderRamadan(container) {
  const { label, times } = await getTodayTimes();
  const today = new Date().toISOString().slice(0, 10);
  const state = getChecklistState(today);
  const dailyDua = await getDailyDua();

  container.innerHTML = `
    <div class="card">
      <h3 style="margin-top:0;">🌙 রমজান মোড</h3>
      <p class="muted small">${esc(label)}-এর হিসাব অনুযায়ী আজকের সেহরি ও ইফতারের সময়।</p>
      <div class="grid-2">
        <div class="quick-action"><span class="qa-icon">🌃</span><span>সেহরি শেষ (ফজরের আগে)</span><div style="font-weight:700;">${times.fajr}</div></div>
        <div class="quick-action"><span class="qa-icon">🌇</span><span>ইফতার (মাগরিব)</span><div style="font-weight:700;">${times.maghrib}</div></div>
      </div>
    </div>
    <div class="card">
      <h3 style="margin-top:0;">আজকের চেকলিস্ট</h3>
      ${CHECKLIST_ITEMS.map((item, i) => `
        <label class="list-item" style="cursor:pointer;">
          <span>${esc(item)}</span>
          <input type="checkbox" data-idx="${i}" ${state[i] ? "checked" : ""}>
        </label>
      `).join("")}
    </div>
    ${dailyDua ? `<div class="card">
      <h3 style="margin-top:0;">আজকের দুআ</h3>
      <strong>${esc(dailyDua.titleBn)}</strong>
      <div class="arabic" style="margin-top:8px;">${esc(dailyDua.arabic)}</div>
      <div class="translit">${esc(dailyDua.pronunciationBn)}</div>
      <div class="meaning">${esc(dailyDua.meaningBn)}</div>
    </div>` : ""}
    <div class="card">
      <p class="muted small">তারাবীহ শেখার তথ্য ও কুরআন খতমের লক্ষ্য নির্ধারণ শীঘ্রই আরও বিস্তারিত আকারে যুক্ত হবে। এই ফিচারের কোনো অংশ ধর্মীয় রায় বা হুকুম নির্ধারণ করে না।</p>
      <button class="btn btn-ghost btn-block" data-nav="fiqh">ফিকহ নোট দেখুন</button>
    </div>
  `;
  container.querySelectorAll("[data-idx]").forEach((cb) => cb.addEventListener("change", (e) => {
    state[e.target.dataset.idx] = e.target.checked;
    setChecklistState(today, state);
  }));
  bindNavClicks(container);
}
