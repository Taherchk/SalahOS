// favorites.js — favorites ("MY SAVED") and personal notes, shared across content types.
import { getItem, setItem, KEYS } from "./storage.js";

export function getFavorites() { return getItem(KEYS.FAVORITES, []); }

export function isFavorite(type, id) {
  return getFavorites().some((f) => f.type === type && f.id === id);
}

export function toggleFavorite(type, id, meta = {}) {
  let favs = getFavorites();
  const idx = favs.findIndex((f) => f.type === type && f.id === id);
  if (idx >= 0) {
    favs.splice(idx, 1);
    setItem(KEYS.FAVORITES, favs);
    return false;
  }
  favs.push({ type, id, meta, savedAt: Date.now() });
  setItem(KEYS.FAVORITES, favs);
  return true;
}

export function removeFavorite(type, id) {
  const favs = getFavorites().filter((f) => !(f.type === type && f.id === id));
  setItem(KEYS.FAVORITES, favs);
}

export function getNotes() { return getItem(KEYS.NOTES, {}); }

export function setNote(type, id, text) {
  const notes = getNotes();
  const key = `${type}:${id}`;
  if (text && text.trim()) notes[key] = { text: text.trim(), updatedAt: Date.now() };
  else delete notes[key];
  setItem(KEYS.NOTES, notes);
}

export function getNote(type, id) {
  const notes = getNotes();
  return notes[`${type}:${id}`]?.text || "";
}
