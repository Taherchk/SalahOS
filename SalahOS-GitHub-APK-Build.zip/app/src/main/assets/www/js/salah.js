// salah.js — Salah recitation library, step-by-step guide, rak'ah flow, simulator.
import { getSalahRecitations, getSalahSteps, findRecitation } from "./data.js";
import { esc, skeletonBlock, bindNavClicks, toast } from "./ui.js";
import { isFavorite, toggleFavorite } from "./favorites.js";
import * as audio from "./audio.js";

const CATEGORY_ORDER = ["Before Salah", "Qiyam", "Ruku", "Qawmah", "Sujood", "Jalsah", "Tashahhud", "Durood", "Dua", "Salam"];

export async function renderSalahLibrary(container) {
  container.innerHTML = skeletonBlock(6);
  const items = await getSalahRecitations();
  const groups = {};
  items.forEach((it) => { (groups[it.category] = groups[it.category] || []).push(it); });
  container.innerHTML = CATEGORY_ORDER.filter((c) => groups[c]).map((cat) => `
    <div class="card">
      <h3 style="margin-top:0;">${esc(cat)}</h3>
      ${groups[cat].map((it) => recitationBlock(it)).join("")}
    </div>
  `).join("") || `<p class="muted">কোনো উপাত্ত পাওয়া যায়নি।</p>`;
  items.forEach((it) => audio.bindAudioControls(container, it.audio, "rec-" + it.id));
  container.querySelectorAll("[data-fav]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.dataset.fav;
      toggleFavorite("recitation", id, { title: btn.dataset.title });
      btn.textContent = isFavorite("recitation", id) ? "❤️" : "🤍";
    });
  });
  bindNavClicks(container);
}

function recitationBlock(it) {
  const fav = isFavorite("recitation", it.id);
  return `<div class="ayah-block">
    <div class="card-row">
      <strong>${esc(it.titleBn)}</strong>
      <button class="btn btn-ghost btn-sm" data-fav="${it.id}" data-title="${esc(it.titleBn)}">${fav ? "❤️" : "🤍"}</button>
    </div>
    <div class="arabic" style="margin-top:8px;">${esc(it.arabic)}</div>
    <div class="translit">${esc(it.pronunciationBn)}</div>
    <div class="meaning">${esc(it.meaningBn)}</div>
    ${it.scholarlyDifference ? `<p class="small"><span class="badge badge-scholarly">বিভিন্ন ফিকহি মতামত</span> ${esc(it.scholarlyDifference)}</p>` : ""}
    <p class="muted small">সূত্রঃ ${esc(it.source || "—")}</p>
    ${audio.audioControlsHtml("rec-" + it.id)}
  </div>`;
}

const PRAYERS = [
  { key: "fajr", label: "ফজর" }, { key: "dhuhr", label: "যুহর" }, { key: "asr", label: "আসর" },
  { key: "maghrib", label: "মাগরিব" }, { key: "isha", label: "ইশা" },
];

export async function renderSalahGuide(container, params) {
  const data = await getSalahSteps();
  const prayerKey = params.prayer;
  if (!prayerKey) {
    container.innerHTML = `
      <div class="card"><p>সালাতের ধাপে ধাপে গাইড দেখতে একটি ওয়াক্ত নির্বাচন করুন।</p></div>
      <div class="grid-2">
        ${PRAYERS.map((p) => {
          const info = data[p.key] || {};
          return `<div class="quick-action" data-nav="salah-guide?prayer=${p.key}">
            <span class="qa-icon">🕌</span><span>${p.label}</span>
            <div class="muted small">${info.rakahCount || "?"} রাকাত</div>
          </div>`;
        }).join("")}
      </div>
      <div class="card">
        <h3 style="margin-top:0;">রাকাতের চিত্র</h3>
        ${renderRakahFlow()}
      </div>
      <div class="card">
        <button class="btn btn-gold btn-block" data-nav="salah-simulator">🎯 সালাহ সিমুলেটর দিয়ে অনুশীলন করুন</button>
      </div>
    `;
    bindNavClicks(container);
    return;
  }
  const prayer = data[prayerKey];
  const steps = data.steps || [];
  let idx = Number(params.step || 0);
  if (idx < 0) idx = 0;
  if (idx >= steps.length) idx = steps.length - 1;

  async function draw() {
    const step = steps[idx];
    const rec = step.recitationId ? await findRecitation(step.recitationId) : null;
    container.innerHTML = `
      <div class="card">
        <div class="card-row">
          <h2 style="margin:0;">${esc(prayer?.nameBn || prayerKey)} — ধাপ ${idx + 1}/${steps.length}</h2>
        </div>
        <div class="progress-bar" style="margin:10px 0;"><span style="width:${((idx + 1) / steps.length) * 100}%"></span></div>
        <h3>${esc(step.positionBn)}</h3>
        <p>${esc(step.instructionBn)}</p>
        ${step.scholarlyDifference ? `<p class="small"><span class="badge badge-scholarly">বিভিন্ন ফিকহি মতামত</span> ${esc(step.scholarlyDifference)}</p>` : ""}
        ${rec ? `
          <div class="arabic" style="margin-top:10px;">${esc(rec.arabic)}</div>
          <div class="translit">${esc(rec.pronunciationBn)}</div>
          <div class="meaning">${esc(rec.meaningBn)}</div>
          ${audio.audioControlsHtml("guide-rec")}
        ` : ""}
        ${step.surahId ? `<p class="small">এই ধাপে সূরা আল-ফাতিহা (ও প্রথম দুই রাকাতে অতিরিক্ত সূরা) পাঠ করা হয়। <a data-nav="surah-reader?id=${step.surahId}" href="javascript:void(0)">সূরাটি পড়ুন</a></p>` : ""}
      </div>
      <div class="card flex gap-8">
        <button class="btn btn-ghost btn-block" id="prevStep" ${idx === 0 ? "disabled" : ""}>← আগের ধাপ</button>
        <button class="btn btn-primary btn-block" id="nextStep" ${idx === steps.length - 1 ? "disabled" : ""}>পরের ধাপ →</button>
      </div>
      ${idx === steps.length - 1 ? `<div class="card"><p class="muted small">${esc(data.note || "")}</p><button class="btn btn-gold btn-block" data-nav="quiz?topic=salah">✅ এই ওয়াক্তের কুইজ দিন</button></div>` : ""}
    `;
    if (rec) audio.bindAudioControls(container, rec.audio, "guide-rec");
    container.querySelector("#prevStep")?.addEventListener("click", () => { idx--; draw(); });
    container.querySelector("#nextStep")?.addEventListener("click", () => { idx++; draw(); });
    bindNavClicks(container);
  }
  draw();
}

export function renderRakahFlow() {
  const flow = ["ক্বিয়াম", "রুকু", "কাওমাহ", "সিজদা", "জলসা", "সিজদা", "পরবর্তী রাকাত"];
  return `<div class="flow-seq">
    ${flow.map((f, i) => `<div class="flow-step">${esc(f)}</div>${i < flow.length - 1 ? '<div class="flow-arrow">↓</div>' : ""}`).join("")}
  </div>`;
}

export async function renderSalahSimulator(container) {
  const data = await getSalahSteps();
  const steps = (data.steps || []).filter((s) => s.recitationId);
  const recitations = await getSalahRecitations();
  let score = 0, qi = 0, order = shuffle([...Array(steps.length).keys()]);

  async function drawQuestion() {
    if (qi >= order.length) {
      container.innerHTML = `<div class="card text-center">
        <h2>🎉 শেষ হয়েছে!</h2>
        <p>আপনার স্কোরঃ ${score}/${steps.length}</p>
        <button class="btn btn-primary btn-block" data-nav="salah-guide">সালাহ গাইডে ফিরুন</button>
      </div>`;
      bindNavClicks(container);
      return;
    }
    const step = steps[order[qi]];
    const correctRec = recitations.find((r) => r.id === step.recitationId);
    const wrongOptions = shuffle(recitations.filter((r) => r.id !== step.recitationId)).slice(0, 2);
    const options = shuffle([correctRec, ...wrongOptions]);
    container.innerHTML = `
      <div class="card">
        <p class="muted small">প্রশ্ন ${qi + 1}/${order.length}</p>
        <h3>আপনি এখন "${esc(step.positionBn)}" অবস্থায় আছেন। কোন দুআ/তাসবীহ পড়বেন?</h3>
        <div id="optWrap">
          ${options.map((o, i) => `<button class="quiz-option" data-idx="${i}">
            <div class="arabic" style="font-size:1.2rem;">${esc(o.arabic)}</div>
            <div class="translit small">${esc(o.pronunciationBn)}</div>
          </button>`).join("")}
        </div>
        <p id="feedback" class="small"></p>
      </div>
    `;
    container.querySelectorAll(".quiz-option").forEach((btn) => {
      btn.addEventListener("click", () => {
        const chosen = options[Number(btn.dataset.idx)];
        const fb = container.querySelector("#feedback");
        if (chosen.id === correctRec.id) {
          btn.classList.add("correct");
          fb.textContent = "✅ সঠিক! পরবর্তী প্রশ্নে যাচ্ছি...";
          score++;
          setTimeout(() => { qi++; drawQuestion(); }, 900);
        } else {
          btn.classList.add("incorrect");
          btn.classList.add("shake");
          fb.textContent = "চেষ্টা চালিয়ে যান — আবার চেষ্টা করুন বা হিন্ট দেখুন।";
          toast("আবার চেষ্টা করুন");
        }
      });
    });
    bindNavClicks(container);
  }
  drawQuestion();
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
