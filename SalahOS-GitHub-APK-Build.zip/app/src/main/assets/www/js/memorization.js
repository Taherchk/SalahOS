// memorization.js — spaced-repetition memorization tracker + practice modes.
import { getItem, setItem, KEYS } from "./storage.js";
import { findSurah, findRecitation, getDuas } from "./data.js";
import { esc, bindNavClicks, toast } from "./ui.js";

const INTERVALS_DAYS = [0, 1, 3, 7, 14, 30];
const STATUS = { NOT_STARTED: "Not Started", LEARNING: "Learning", PRACTICING: "Practicing", MEMORIZED: "Memorized", NEEDS_REVIEW: "Needs Review" };

function store() { return getItem(KEYS.MEMORIZATION, {}); }
function save(s) { setItem(KEYS.MEMORIZATION, s); }
function key(type, id) { return `${type}:${id}`; }

export function getProgress(type, id) {
  const all = store();
  const rec = all[key(type, id)];
  if (!rec) return null;
  return { ...rec, percent: statusToPercent(rec.status) };
}

function statusToPercent(status) {
  return { [STATUS.NOT_STARTED]: 0, [STATUS.LEARNING]: 25, [STATUS.PRACTICING]: 55, [STATUS.NEEDS_REVIEW]: 70, [STATUS.MEMORIZED]: 100 }[status] ?? 0;
}

export function startItem(type, id, title) {
  const all = store();
  const k = key(type, id);
  if (!all[k]) {
    all[k] = { type, id, title, status: STATUS.LEARNING, stage: 0, lastReview: Date.now(), nextReview: Date.now(), history: [] };
    save(all);
  }
  return all[k];
}

export function rate(type, id, rating) {
  // rating: "easy" | "good" | "hard"
  const all = store();
  const k = key(type, id);
  const rec = all[k] || startItem(type, id, id);
  rec.history = rec.history || [];
  rec.history.push({ rating, at: Date.now() });
  if (rating === "hard") {
    rec.stage = Math.max(0, rec.stage - 1);
    rec.status = STATUS.NEEDS_REVIEW;
  } else {
    rec.stage = Math.min(INTERVALS_DAYS.length - 1, rec.stage + (rating === "easy" ? 2 : 1));
    rec.status = rec.stage >= INTERVALS_DAYS.length - 1 ? STATUS.MEMORIZED : STATUS.PRACTICING;
  }
  const days = INTERVALS_DAYS[rec.stage] ?? 30;
  rec.lastReview = Date.now();
  rec.nextReview = Date.now() + days * 86400000;
  all[k] = rec;
  save(all);
  return rec;
}

export function allDue() {
  const all = store();
  const now = Date.now();
  return Object.values(all).filter((r) => r.nextReview <= now && r.status !== STATUS.MEMORIZED);
}

export function allItems() { return Object.values(store()); }

export function weakestItems(n = 3) {
  const items = allItems();
  return items
    .filter((i) => i.status !== STATUS.MEMORIZED)
    .sort((a, b) => statusToPercent(a.status) - statusToPercent(b.status))
    .slice(0, n);
}

const MODES = [
  { key: "listen", label: "শুনুন" }, { key: "read", label: "পড়ুন" },
  { key: "hide_arabic", label: "আরবি লুকান" }, { key: "hide_translit", label: "উচ্চারণ লুকান" },
  { key: "hide_meaning", label: "অর্থ লুকান" }, { key: "recall", label: "স্মরণ অনুশীলন" },
];

export async function renderMemorization(container, params) {
  const type = params.type;
  const id = params.id;
  let item = null, title = "", arabic = "", translit = "", meaning = "", audioSrc = null;

  if (type === "surah") {
    const s = await findSurah(id);
    if (!s) { container.innerHTML = `<div class="card">আইটেম পাওয়া যায়নি।</div>`; return; }
    title = s.nameBangla;
    arabic = s.ayahs.map((a) => a.arabic).join(" \u06dd ");
    translit = s.ayahs.map((a) => a.transliteration).join(" / ");
    meaning = s.ayahs.map((a) => a.translationBn).join(" ");
  } else if (type === "recitation") {
    const r = await findRecitation(id);
    if (!r) { container.innerHTML = `<div class="card">আইটেম পাওয়া যায়নি।</div>`; return; }
    title = r.titleBn; arabic = r.arabic; translit = r.pronunciationBn; meaning = r.meaningBn; audioSrc = r.audio;
  } else if (type === "dua") {
    const duas = await getDuas();
    const d = duas.find((x) => x.id === id);
    if (!d) { container.innerHTML = `<div class="card">আইটেম পাওয়া যায়নি।</div>`; return; }
    title = d.titleBn; arabic = d.arabic; translit = d.pronunciationBn; meaning = d.meaningBn; audioSrc = d.audio;
  } else {
    renderMemorizationHub(container);
    return;
  }

  startItem(type, id, title);
  let mode = "read";

  function draw() {
    const hideArabic = mode === "hide_arabic" || mode === "recall";
    const hideTranslit = mode === "hide_translit" || mode === "recall";
    const hideMeaning = mode === "hide_meaning" || mode === "recall";
    container.innerHTML = `
      <div class="card">
        <h3 style="margin-top:0;">${esc(title)}</h3>
        <div class="pill-row">${MODES.map((m) => `<button class="pill ${mode === m.key ? "active" : ""}" data-mode="${m.key}">${m.label}</button>`).join("")}</div>
        ${mode === "listen" && audioSrc ? `<button class="btn btn-primary btn-block" id="playBtn">▶️ শুনুন</button>` : ""}
        ${!hideArabic ? `<div class="arabic" style="margin-top:10px;">${esc(arabic)}</div>` : `<div class="skeleton" style="height:48px;"></div>`}
        ${!hideTranslit ? `<div class="translit">${esc(translit)}</div>` : ""}
        ${!hideMeaning ? `<div class="meaning">${esc(meaning)}</div>` : ""}
        ${mode === "recall" ? `<button class="btn btn-outline btn-block" id="revealBtn">উত্তর দেখুন</button>` : ""}
      </div>
      <div class="card">
        <p class="muted small">আপনার মনে হয় এটি কেমন ছিল?</p>
        <div class="flex gap-8">
          <button class="btn btn-danger btn-sm" data-rate="hard">কঠিন</button>
          <button class="btn btn-ghost btn-sm" data-rate="good">ভালো</button>
          <button class="btn btn-primary btn-sm" data-rate="easy">সহজ</button>
        </div>
        <p class="muted small mt-8">নোটঃ এই অ্যাপ স্বয়ংক্রিয়ভাবে বৈজ্ঞানিকভাবে মুখস্থ প্রমাণ করতে পারে না — এটি কেবল আপনার নিজস্ব অনুশীলন ট্র্যাক করতে সাহায্য করে।</p>
      </div>
    `;
    container.querySelectorAll("[data-mode]").forEach((b) => b.addEventListener("click", () => { mode = b.dataset.mode; draw(); }));
    container.querySelector("#revealBtn")?.addEventListener("click", () => { mode = "read"; draw(); });
    container.querySelector("#playBtn")?.addEventListener("click", async () => {
      const a = (await import("./audio.js"));
      a.play(audioSrc, "memo-audio");
    });
    container.querySelectorAll("[data-rate]").forEach((b) => b.addEventListener("click", () => {
      rate(type, id, b.dataset.rate);
      toast("পরবর্তী পর্যালোচনার সময় নির্ধারিত হয়েছে।");
      renderMemorizationHub(container);
    }));
    bindNavClicks(container);
  }
  draw();
}

export function renderMemorizationHub(container) {
  const items = allItems();
  const due = allDue();
  container.innerHTML = `
    <div class="card">
      <h3 style="margin-top:0;">আজকের পর্যালোচনা</h3>
      ${due.length ? due.map((i) => `<div class="list-item" data-nav="memorization?type=${i.type}&id=${i.id}">
          <span>${esc(i.title)}</span><span class="badge">${esc(i.status)}</span>
        </div>`).join("") : `<p class="muted">আজ পর্যালোচনার জন্য কিছু নেই। নতুন কিছু শিখুন!</p>`}
    </div>
    <div class="card">
      <h3 style="margin-top:0;">সকল আইটেম</h3>
      ${items.length ? items.map((i) => `
        <div class="list-item" data-nav="memorization?type=${i.type}&id=${i.id}">
          <div style="flex:1;">
            <div>${esc(i.title)}</div>
            <div class="progress-bar" style="margin-top:4px;"><span style="width:${statusToPercent(i.status)}%"></span></div>
          </div>
          <span class="badge">${esc(i.status)}</span>
        </div>`).join("") : `<p class="muted">এখনও কোনো আইটেম শুরু করা হয়নি। সূরা বা দুআ পাতা থেকে "মুখস্থ অনুশীলন" চাপুন।</p>`}
    </div>
  `;
  bindNavClicks(container);
}
