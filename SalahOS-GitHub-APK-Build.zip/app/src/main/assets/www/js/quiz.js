// quiz.js — quiz engine supporting mcq, true_false, fill_blank, arrange.
import { getQuiz, getSurahs } from "./data.js";
import { getItem, setItem, KEYS } from "./storage.js";
import { esc, bindNavClicks, toast } from "./ui.js";

function stats() { return getItem(KEYS.QUIZ_STATS, { byTopic: {}, totalCorrect: 0, totalAnswered: 0 }); }
function saveStats(s) { setItem(KEYS.QUIZ_STATS, s); }

function recordAnswer(topic, correct) {
  const s = stats();
  s.totalAnswered++;
  if (correct) s.totalCorrect++;
  s.byTopic[topic] = s.byTopic[topic] || { correct: 0, wrong: 0 };
  s.byTopic[topic][correct ? "correct" : "wrong"]++;
  saveStats(s);
}

export function weakTopics() {
  const s = stats();
  return Object.entries(s.byTopic)
    .map(([topic, v]) => ({ topic, missRate: v.wrong / Math.max(1, v.correct + v.wrong), total: v.correct + v.wrong }))
    .filter((t) => t.total >= 2)
    .sort((a, b) => b.missRate - a.missRate);
}

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}

const AR_DIGITS = ["০","১","২","৩","৪","৫","৬","৭","৮","৯"];
const bnNum = (n) => String(n).replace(/\d/g, (d) => AR_DIGITS[d]);

// Auto-generated questions from the surah data (ayah count / identify surah by first ayah).
async function generatedQuestions() {
  const surahs = (await getSurahs()).filter((s) => s.id < 2000);
  const out = [];
  surahs.forEach((s) => {
    const counts = [...new Set([s.ayahCount, s.ayahCount + 1, Math.max(1, s.ayahCount - 1), s.ayahCount + 2])].slice(0, 4);
    const opts = shuffle(counts);
    out.push({ id: `gen-count-${s.id}`, type: "mcq", difficulty: "beginner", topic: "surah",
      questionBn: `সূরা ${s.nameBangla}-তে কয়টি আয়াত আছে?`, options: opts.map(bnNum), correctIndex: opts.indexOf(s.ayahCount),
      explanationBn: `সূরা ${s.nameBangla}-তে ${bnNum(s.ayahCount)}টি আয়াত আছে।` });
    const others = shuffle(surahs.filter((x) => x.id !== s.id)).slice(0, 3);
    const names = shuffle([s, ...others]);
    out.push({ id: `gen-id-${s.id}`, type: "mcq", difficulty: "intermediate", topic: "surah",
      questionBn: `এই আয়াতটি কোন সূরার? ${s.ayahs[0].arabic}`, options: names.map((x) => x.nameBangla), correctIndex: names.indexOf(s),
      explanationBn: `এটি সূরা ${s.nameBangla}-এর প্রথম আয়াত।` });
  });
  return out;
}

export async function renderQuiz(container, params) {
  let all = [...(await getQuiz()), ...(await generatedQuestions())];
  if (params.difficulty) all = all.filter((q) => q.difficulty === params.difficulty);
  if (params.topic) all = all.filter((q) => q.topic === params.topic || params.topic === "salah");
  if (!all.length) all = await getQuiz();
  const questions = shuffle(all).slice(0, Math.min(8, all.length));
  let qi = 0, score = 0;

  function draw() {
    if (qi >= questions.length) {
      const pct = Math.round((score / questions.length) * 100);
      container.innerHTML = `
        <div class="card text-center">
          <h2>কুইজ সম্পন্ন!</h2>
          <p style="font-size:1.4rem;font-weight:800;color:var(--emerald-light);">${score}/${questions.length} (${pct}%)</p>
          ${weakTopics()[0] ? `<p class="muted">সুপারিশঃ "${esc(weakTopics()[0].topic)}" বিষয়ে আরও অনুশীলন করুন।</p>` : ""}
          <div class="flex gap-8">
            <button class="btn btn-ghost btn-block" data-nav="learn">শেখা পাতায়</button>
            <button class="btn btn-primary btn-block" id="retryBtn">আবার দিন</button>
          </div>
        </div>`;
      container.querySelector("#retryBtn").addEventListener("click", () => { qi = 0; score = 0; draw(); });
      bindNavClicks(container);
      return;
    }
    const q = questions[qi];
    container.innerHTML = `
      <div class="card">
        <p class="muted small">প্রশ্ন ${qi + 1}/${questions.length} · ${esc(q.difficulty || "")}</p>
        <h3>${esc(q.questionBn)}</h3>
        <div id="qBody"></div>
        <p id="qFeedback" class="small mt-8"></p>
        <button class="btn btn-primary btn-block" id="nextBtn" style="display:none;">পরবর্তী →</button>
      </div>`;
    const body = container.querySelector("#qBody");
    const feedback = container.querySelector("#qFeedback");
    const nextBtn = container.querySelector("#nextBtn");

    function finishQuestion(correct, explanation) {
      recordAnswer(q.topic, correct);
      if (correct) score++;
      feedback.textContent = (correct ? "✅ সঠিক! " : "ℹ️ ") + (explanation || "");
      nextBtn.style.display = "block";
      nextBtn.addEventListener("click", () => { qi++; draw(); }, { once: true });
    }

    if (q.type === "mcq") {
      body.innerHTML = q.options.map((o, i) => `<button class="quiz-option" data-i="${i}">${esc(o)}</button>`).join("");
      body.querySelectorAll(".quiz-option").forEach((btn) => btn.addEventListener("click", () => {
        const i = Number(btn.dataset.i);
        const correct = i === q.correctIndex;
        body.querySelectorAll(".quiz-option").forEach((b2, j) => {
          if (j === q.correctIndex) b2.classList.add("correct");
          else if (j === i) b2.classList.add("incorrect");
          b2.disabled = true;
        });
        finishQuestion(correct, q.explanationBn);
      }, { once: true }));
    } else if (q.type === "true_false") {
      body.innerHTML = `<button class="quiz-option" data-v="true">সঠিক</button><button class="quiz-option" data-v="false">ভুল</button>`;
      body.querySelectorAll(".quiz-option").forEach((btn) => btn.addEventListener("click", () => {
        const v = btn.dataset.v === "true";
        const correct = v === q.correctAnswer;
        btn.classList.add(correct ? "correct" : "incorrect");
        body.querySelectorAll(".quiz-option").forEach((b) => (b.disabled = true));
        finishQuestion(correct, q.explanationBn);
      }, { once: true }));
    } else if (q.type === "fill_blank") {
      body.innerHTML = `<input type="text" id="fillInput" placeholder="উত্তর লিখুন"><button class="btn btn-primary btn-block mt-8" id="submitFill">জমা দিন</button>`;
      body.querySelector("#submitFill").addEventListener("click", () => {
        const val = body.querySelector("#fillInput").value.trim();
        const correct = val && q.answerBn && val.replace(/\s/g, "") === q.answerBn.replace(/\s/g, "");
        body.querySelector("#fillInput").disabled = true;
        body.querySelector("#submitFill").disabled = true;
        finishQuestion(!!correct, `সঠিক উত্তরঃ ${q.answerBn}। ${q.explanationBn || ""}`);
      });
    } else if (q.type === "arrange") {
      let current = shuffle(q.itemsBn.map((t, i) => ({ t, i })));
      function drawArrange() {
        body.innerHTML = current.map((item, pos) => `<button class="quiz-option" data-pos="${pos}">${pos + 1}. ${esc(item.t)} ${pos > 0 ? "⬆️" : ""}</button>`).join("")
          + `<button class="btn btn-primary btn-block mt-8" id="checkOrder">ক্রম পরীক্ষা করুন</button>`;
        body.querySelectorAll("[data-pos]").forEach((btn) => btn.addEventListener("click", () => {
          const pos = Number(btn.dataset.pos);
          if (pos > 0) { [current[pos - 1], current[pos]] = [current[pos], current[pos - 1]]; drawArrange(); }
        }));
        body.querySelector("#checkOrder").addEventListener("click", () => {
          const correct = current.every((item, idx) => item.i === q.correctOrder[idx]);
          finishQuestion(correct, q.explanationBn);
          body.querySelectorAll("button").forEach((b) => (b.disabled = true));
        });
      }
      drawArrange();
    } else {
      body.innerHTML = `<p class="muted">এই প্রশ্নের ধরন সমর্থিত নয়।</p>`;
      finishQuestion(false, "");
    }
  }
  draw();
}

export function getQuizStats() { return stats(); }
