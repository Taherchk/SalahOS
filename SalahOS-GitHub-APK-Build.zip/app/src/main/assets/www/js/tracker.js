// tracker.js — optional, private, manual Salah tracker. Never auto-infers completion.
import { getItem, setItem, KEYS } from "./storage.js";
import { esc, bindNavClicks } from "./ui.js";

const PRAYERS = [
  { key: "fajr", label: "ফজর" }, { key: "dhuhr", label: "যুহর" }, { key: "asr", label: "আসর" },
  { key: "maghrib", label: "মাগরিব" }, { key: "isha", label: "ইশা" },
];

function todayKey(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function getLog() { return getItem(KEYS.TRACKER, {}); }
function saveLog(l) { setItem(KEYS.TRACKER, l); }

export function getStatus(dateKey, prayer) {
  const log = getLog();
  return log[dateKey]?.[prayer] || "NOT_RECORDED";
}

export function setStatus(dateKey, prayer, status) {
  const log = getLog();
  log[dateKey] = log[dateKey] || {};
  log[dateKey][prayer] = status;
  saveLog(log);
}

export async function renderTracker(container) {
  const view = "daily";
  const today = todayKey();
  function draw() {
    const log = getLog();
    container.innerHTML = `
      <div class="card">
        <p class="muted small">এটি একটি সম্পূর্ণ ব্যক্তিগত ট্র্যাকার — তথ্য শুধুমাত্র আপনার ডিভাইসে সংরক্ষিত হয়। অ্যাপ নিজে থেকে কখনো সালাত আদায় হয়েছে বা মিস হয়েছে তা ধরে নেয় না; আপনাকে নিজেই রেকর্ড করতে হবে।</p>
      </div>
      <div class="card">
        <h3 style="margin-top:0;">আজ — ${esc(today)}</h3>
        ${PRAYERS.map((p) => {
          const st = getStatus(today, p.key);
          return `<div class="list-item">
            <span>${p.label}</span>
            <div class="flex gap-8">
              <button class="btn btn-sm ${st === "COMPLETED" ? "btn-primary" : "btn-ghost"}" data-set="${p.key}:COMPLETED">✓ আদায় হয়েছে</button>
              <button class="btn btn-sm ${st === "NOT_RECORDED" ? "btn-outline" : "btn-ghost"}" data-set="${p.key}:NOT_RECORDED">রেকর্ড নেই</button>
            </div>
          </div>`;
        }).join("")}
      </div>
      <div class="card">
        <h3 style="margin-top:0;">গত ৭ দিন</h3>
        ${renderWeek(log)}
      </div>
    `;
    container.querySelectorAll("[data-set]").forEach((btn) => btn.addEventListener("click", () => {
      const [prayer, status] = btn.dataset.set.split(":");
      setStatus(today, prayer, status);
      draw();
    }));
    bindNavClicks(container);
  }
  draw();
}

function renderWeek(log) {
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    days.push(todayKey(d));
  }
  return `<div style="overflow-x:auto;">
    <table style="width:100%;border-collapse:collapse;font-size:0.78rem;">
      <tr><th></th>${PRAYERS.map((p) => `<th style="padding:4px;">${p.label}</th>`).join("")}</tr>
      ${days.map((d) => `<tr><td class="muted" style="padding:4px;">${d.slice(5)}</td>${PRAYERS.map((p) => {
        const st = log[d]?.[p.key];
        return `<td style="text-align:center;padding:4px;">${st === "COMPLETED" ? "✅" : "—"}</td>`;
      }).join("")}</tr>`).join("")}
    </table>
  </div>`;
}
