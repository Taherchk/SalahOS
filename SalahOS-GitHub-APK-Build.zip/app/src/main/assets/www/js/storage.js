// storage.js — safe localStorage wrapper. Never throws; degrades gracefully.
const PREFIX = "salahos:";
let available = true;
try {
  const t = "__salahos_test__";
  localStorage.setItem(t, "1");
  localStorage.removeItem(t);
} catch (e) {
  available = false;
  console.warn("SalahOS: localStorage unavailable, falling back to in-memory store.", e);
}
const memoryFallback = {};

export function setItem(key, value) {
  const full = PREFIX + key;
  try {
    const json = JSON.stringify(value);
    if (available) localStorage.setItem(full, json);
    else memoryFallback[full] = json;
  } catch (e) {
    console.warn("SalahOS storage write failed for", key, e);
  }
}

export function getItem(key, fallback = null) {
  const full = PREFIX + key;
  try {
    const raw = available ? localStorage.getItem(full) : memoryFallback[full];
    if (raw == null) return fallback;
    return JSON.parse(raw);
  } catch (e) {
    console.warn("SalahOS storage read failed for", key, e);
    return fallback;
  }
}

export function removeItem(key) {
  const full = PREFIX + key;
  try {
    if (available) localStorage.removeItem(full);
    else delete memoryFallback[full];
  } catch (e) { /* ignore */ }
}

export function allKeys() {
  if (!available) return Object.keys(memoryFallback).map(k => k.slice(PREFIX.length));
  const out = [];
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith(PREFIX)) out.push(k.slice(PREFIX.length));
  }
  return out;
}

export function clearAll() {
  allKeys().forEach(removeItem);
}

export const KEYS = {
  LANGUAGE: "language",
  THEME: "theme",
  ARABIC_SIZE: "arabicFontSize",
  ONBOARDED: "onboarded",
  FAVORITES: "favorites",
  NOTES: "notes",
  TRACKER: "tracker",
  MEMORIZATION: "memorization",
  QUIZ_STATS: "quizStats",
  SETTINGS: "settings",
  LOCATION: "location",
  TASBIH_HISTORY: "tasbihHistory",
  RECENT_SEARCHES: "recentSearches",
  AUDIO_PREFS: "audioPrefs",
};
