// app.js — SalahOS entry point. Wires together router, views, PWA + offline behavior.
import { register, navigate, initRouter } from "./router.js";
import { getItem, setItem, KEYS } from "./storage.js";
import { esc, toast, bindNavClicks, progressBar, applyReducedMotion, emptyState, skeletonBlock } from "./ui.js";
import * as dataMod from "./data.js";
import * as prayerTime from "./prayer-time.js";
import * as surahMod from "./surah.js";
import * as salahMod from "./salah.js";
import * as duaMod from "./dua.js";
import * as dhikrMod from "./dhikr.js";
import * as memo from "./memorization.js";
import * as quizMod from "./quiz.js";
import * as trackerMod from "./tracker.js";
import * as searchMod from "./search.js";
import * as settingsMod from "./settings.js";
import * as fiqhMod from "./fiqh.js";
import * as ramadanMod from "./ramadan.js";
import * as favorites from "./favorites.js";
import * as guides from "./guides.js";
import * as qibla from "./qibla.js";

/* ---------------- Theme / Accessibility init ---------------- */
settingsMod.applyTheme(getItem(KEYS.THEME, "system"));
settingsMod.applyArabicSize(getItem(KEYS.ARABIC_SIZE, "medium"));
applyReducedMotion();
if (getSettingsSafe().reducedMotion) document.body.classList.add("reduced-motion");
function getSettingsSafe() { try { return settingsMod.getSettings(); } catch (e) { return {}; } }

document.getElementById("btnTheme").addEventListener("click", () => {
  const cur = getItem(KEYS.THEME, "system");
  const next = cur === "dark" ? "light" : cur === "light" ? "system" : "dark";
  settingsMod.applyTheme(next);
  toast(next === "system" ? "থিমঃ সিস্টেম" : next === "dark" ? "থিমঃ ডার্ক" : "থিমঃ লাইট");
});

/* ---------------- Offline indicator ---------------- */
function updateOnlineStatus() {
  document.getElementById("offlineBanner").classList.toggle("show", !navigator.onLine);
}
window.addEventListener("online", updateOnlineStatus);
window.addEventListener("offline", updateOnlineStatus);
updateOnlineStatus();

/* ---------------- Service Worker ---------------- */
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("service-worker.js").catch((e) => console.warn("SW register failed", e));
  });
}

/* ---------------- Search sheet ---------------- */
const searchSheet = document.getElementById("searchSheet");
document.getElementById("btnSearch").addEventListener("click", () => {
  searchSheet.style.display = "block";
  document.getElementById("searchInput").focus();
  drawSearchDefault();
});
document.getElementById("btnCloseSearch").addEventListener("click", () => { searchSheet.style.display = "none"; });
let searchDebounce = null;
document.getElementById("searchInput").addEventListener("input", (e) => {
  clearTimeout(searchDebounce);
  const q = e.target.value;
  searchDebounce = setTimeout(async () => {
    if (!q.trim()) { drawSearchDefault(); return; }
    const results = await searchMod.searchAll(q);
    document.getElementById("searchResults").innerHTML = searchMod.renderResults(results);
    bindSearchNav();
  }, 200);
});
document.getElementById("searchInput").addEventListener("change", (e) => searchMod.addRecentSearch(e.target.value));

function drawSearchDefault() {
  const recent = searchMod.getRecentSearches();
  const popular = ["সালাত", "ফাতিহা", "রুকু", "সিজদা", "আত্তাহিয়্যাতু", "দুরূদ"];
  document.getElementById("searchResults").innerHTML = `
    ${recent.length ? `<h4>সাম্প্রতিক সার্চ</h4><div class="pill-row">${recent.map((r) => `<button class="pill" data-q="${esc(r)}">${esc(r)}</button>`).join("")}</div>` : ""}
    <h4>জনপ্রিয় বিষয়</h4>
    <div class="pill-row">${popular.map((p) => `<button class="pill" data-q="${esc(p)}">${esc(p)}</button>`).join("")}</div>
  `;
  document.getElementById("searchResults").querySelectorAll("[data-q]").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.getElementById("searchInput").value = btn.dataset.q;
      document.getElementById("searchInput").dispatchEvent(new Event("input"));
    });
  });
}
function bindSearchNav() {
  document.getElementById("searchResults").querySelectorAll("[data-nav]").forEach((el) => {
    el.addEventListener("click", () => {
      searchSheet.style.display = "none";
      navigate(el.getAttribute("data-nav").split("?")[0], Object.fromEntries(new URLSearchParams(el.getAttribute("data-nav").split("?")[1] || "")));
    });
  });
}

/* ---------------- Onboarding ---------------- */
function runOnboardingIfNeeded() {
  if (getItem(KEYS.ONBOARDED, false)) return;
  const el = document.getElementById("onboarding");
  const content = document.getElementById("onboardingContent");
  el.style.display = "block";
  let screen = 0;
  const goal = { value: null };
  const screens = [
    () => `<h1 style="font-size:2rem;">🕌 SalahOS</h1>
      <p style="font-size:1.05rem;">আপনার ব্যক্তিগত সালাত শেখার সঙ্গী।</p>
      <button class="btn btn-gold btn-block mt-8" id="nextBtn">শুরু করুন →</button>`,
    () => `<h2>ভাষা নির্বাচন করুন</h2>
      <button class="btn btn-ghost btn-block mt-8" data-lang="bn">বাংলা ✓</button>
      <button class="btn btn-ghost btn-block mt-8" data-lang="en">English (coming soon)</button>`,
    () => `<h2>নামাজের সময় সেটআপ</h2>
      <p>আনুমানিক স্থানীয় নামাজের সময় গণনার জন্য অবস্থান ব্যবহার করা হয়। আপনার অবস্থান কোনো সার্ভারে পাঠানো হয় না।</p>
      <button class="btn btn-gold btn-block mt-8" id="useLocBtn">📍 অবস্থান ব্যবহার করুন</button>
      <button class="btn btn-ghost btn-block mt-8" id="chooseCityBtn">🏙️ শহর নির্বাচন করুন</button>
      <button class="btn btn-ghost btn-block mt-8" id="skipLocBtn">পরে করবো</button>`,
    () => `<h2>আপনার লক্ষ্য কী?</h2>
      ${["সালাত শেখা", "সূরা মুখস্থ করা", "দুআ শেখা", "তিলাওয়াত উন্নত করা", "সব কিছু"].map((g) => `<button class="btn btn-ghost btn-block mt-8" data-goal="${esc(g)}">${esc(g)}</button>`).join("")}`,
    () => `<h2>প্রস্তুত! 🎉</h2>
      <p>চলুন শেখা শুরু করি।</p>
      <button class="btn btn-gold btn-block mt-8" id="finishBtn">SalahOS শুরু করুন</button>`,
  ];
  function draw() {
    content.innerHTML = screens[screen]();
    content.querySelector("#nextBtn")?.addEventListener("click", () => { screen++; draw(); });
    content.querySelectorAll("[data-lang]").forEach((b) => b.addEventListener("click", () => { screen++; draw(); }));
    content.querySelector("#useLocBtn")?.addEventListener("click", async () => {
      try {
        const pos = await prayerTime.requestGeolocation();
        const loc = prayerTime.getLocationSettings();
        loc.mode = "gps"; loc.lat = pos.lat; loc.lng = pos.lng;
        prayerTime.setLocationSettings(loc);
        toast("অবস্থান সংরক্ষিত হয়েছে");
      } catch (e) { toast("অবস্থান পাওয়া যায়নি, পরে সেটিংস থেকে শহর নির্বাচন করুন।"); }
      screen++; draw();
    });
    content.querySelector("#chooseCityBtn")?.addEventListener("click", () => { screen++; draw(); });
    content.querySelector("#skipLocBtn")?.addEventListener("click", () => { screen++; draw(); });
    content.querySelectorAll("[data-goal]").forEach((b) => b.addEventListener("click", () => { goal.value = b.dataset.goal; screen++; draw(); }));
    content.querySelector("#finishBtn")?.addEventListener("click", () => {
      setItem(KEYS.ONBOARDED, true);
      el.style.display = "none";
      navigate("home");
    });
  }
  draw();
}

/* ---------------- Hijri date (approximate, Umm al-Qura calendar via Intl) ---------------- */
function hijriDate() {
  try {
    const t = new Intl.DateTimeFormat("bn-u-ca-islamic-umalqura", { day: "numeric", month: "long", year: "numeric" }).format(new Date());
    return "হিজরি (আনুমানিক): " + t.replace(/\s*যুগ$/, "");
  } catch (e) { return ""; }
}

/* ---------------- HOME ---------------- */
let countdownTimer = null;
async function renderHome(container) {
  container.innerHTML = skeletonBlock(5);
  const [{ label, times }, dailyDua, dailyDhikr] = await Promise.all([
    prayerTime.getTodayTimes(), duaMod.getDailyDua(), dhikrMod.getDailyDhikr(),
  ]);
  const weakest = memo.weakestItems(1)[0];
  const favCount = favorites.getFavorites().length;

  container.innerHTML = `
    <div class="card">
      <h2 class="arabic" style="margin:0;text-align:left;">السلام عليكم</h2>
      <p class="muted" style="margin-bottom:2px;">${new Date().toLocaleDateString("bn-BD", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}</p>
      <p class="muted small" style="margin-top:0;">${hijriDate()}</p>
      <div class="card-row" style="margin-top:8px;">
        <div>
          <div class="muted small">পরবর্তী নামাজ</div>
          <div id="nextPrayerName" style="font-size:1.3rem;font-weight:800;color:var(--emerald-light);"></div>
        </div>
        <div style="text-align:right;">
          <div id="nextPrayerTime" style="font-weight:700;"></div>
          <div id="countdown" class="muted" style="font-variant-numeric:tabular-nums;"></div>
        </div>
      </div>
      <p class="muted small mt-8">হিসাবঃ ${esc(label)} · ${esc(times.method)}</p>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">আজকের নামাজ</h3>
      <div id="todayPrayers"></div>
    </div>

    <div class="card">
      <h3 style="margin-top:0;">দ্রুত অ্যাক্সেস</h3>
      <div class="grid-4">
        <div class="quick-action" data-nav="salah-guide"><span class="qa-icon">🕌</span><span>সালাহ শিখুন</span></div>
        <div class="quick-action" data-nav="surahs"><span class="qa-icon">📖</span><span>সূরা</span></div>
        <div class="quick-action" data-nav="duas"><span class="qa-icon">🤲</span><span>দুআ</span></div>
        <div class="quick-action" data-nav="tasbih"><span class="qa-icon">📿</span><span>তাসবীহ</span></div>
        <div class="quick-action" data-nav="wudu"><span class="qa-icon">💧</span><span>ওযু</span></div>
        <div class="quick-action" data-nav="qibla"><span class="qa-icon">🧭</span><span>কিবলা</span></div>
        <div class="quick-action" data-nav="adhan"><span class="qa-icon">📢</span><span>আযান</span></div>
        <div class="quick-action" data-nav="quiz"><span class="qa-icon">❓</span><span>কুইজ</span></div>
      </div>
    </div>

    ${weakest ? `<div class="card">
      <h3 style="margin-top:0;">চালিয়ে যান</h3>
      <p>${esc(weakest.title)} <span class="badge">${esc(weakest.status)}</span></p>
      ${progressBar(memo.getProgress(weakest.type, weakest.id)?.percent || 0)}
      <p class="muted small mt-8">আজকের সুপারিশঃ ${esc(weakest.title)} ৫ মিনিট অনুশীলন করুন।</p>
      <button class="btn btn-primary btn-block mt-8" data-nav="memorization?type=${weakest.type}&id=${weakest.id}">অনুশীলন শুরু করুন</button>
    </div>` : `<div class="card">
      <h3 style="margin-top:0;">শেখা শুরু করুন</h3>
      <p class="muted">এখনো কোনো মুখস্থ অনুশীলন শুরু হয়নি।</p>
      <button class="btn btn-primary btn-block" data-nav="surahs">সূরা দিয়ে শুরু করুন</button>
    </div>`}

    ${dailyDua ? `<div class="card">
      <h3 style="margin-top:0;">আজকের দুআ</h3>
      ${duaMod.duaBlock(dailyDua)}
    </div>` : ""}

    ${dailyDhikr ? `<div class="card">
      <h3 style="margin-top:0;">আজকের যিকর</h3>
      <strong>${esc(dailyDhikr.titleBn)}</strong>
      <div class="arabic" style="margin-top:6px;">${esc(dailyDhikr.arabic)}</div>
      <p class="muted small">লক্ষ্যঃ ${dailyDhikr.recommendedCount}</p>
      <button class="btn btn-gold btn-block" data-nav="tasbih?dhikr=${dailyDhikr.id}">📿 তাসবীহ শুরু করুন</button>
    </div>` : ""}

    <div class="card">
      <h3 style="margin-top:0;">শেখার অগ্রগতি</h3>
      <p class="muted small">মুখস্থের আইটেমঃ ${memo.allItems().length} · পছন্দের তালিকা (সেভড)ঃ ${favCount} · কুইজ উত্তরঃ ${quizMod.getQuizStats().totalAnswered}</p>
    </div>
  `;

  drawTodayPrayers(container, times);
  startCountdown(container, times);
  if (dailyDua) {
    const { bindAudioControls } = await import("./audio.js");
    bindAudioControls(container, dailyDua.audio, "dua-" + dailyDua.id);
    container.querySelectorAll(`[data-fav="${dailyDua.id}"]`).forEach((btn) => btn.addEventListener("click", () => {
      const nowFav = favorites.toggleFavorite("dua", dailyDua.id, { title: dailyDua.titleBn });
      btn.textContent = nowFav ? "❤️" : "🤍";
    }));
  }
  bindNavClicks(container);
}

function drawTodayPrayers(container, times) {
  const wrap = container.querySelector("#todayPrayers");
  if (!wrap) return;
  const today = new Date();
  const dateKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  wrap.innerHTML = prayerTime.order().map((key) => {
    const st = trackerMod.getStatus(dateKey, key);
    return `<div class="list-item">
      <span>${prayerTime.labelsBn()[key]}</span>
      <span class="muted">${times[key]}</span>
      <button class="btn btn-sm ${st === "COMPLETED" ? "btn-primary" : "btn-ghost"}" data-mark="${key}">${st === "COMPLETED" ? "✓ আদায় হয়েছে" : "রেকর্ড করুন"}</button>
    </div>`;
  }).join("");
  wrap.querySelectorAll("[data-mark]").forEach((btn) => btn.addEventListener("click", () => {
    const key = btn.dataset.mark;
    const cur = trackerMod.getStatus(dateKey, key);
    trackerMod.setStatus(dateKey, key, cur === "COMPLETED" ? "NOT_RECORDED" : "COMPLETED");
    drawTodayPrayers(container, times);
  }));
}

function startCountdown(container, times) {
  clearInterval(countdownTimer);
  function tick() {
    const next = prayerTime.nextPrayer(times);
    const nameEl = container.querySelector("#nextPrayerName");
    const timeEl = container.querySelector("#nextPrayerTime");
    const cdEl = container.querySelector("#countdown");
    if (!nameEl) { clearInterval(countdownTimer); return; }
    nameEl.textContent = next.label;
    timeEl.textContent = next.timeStr;
    const now = new Date();
    const nowHours = now.getHours() + now.getMinutes() / 3600 + now.getSeconds() / 3600;
    let diffHours = next.raw - nowHours;
    if (diffHours < 0) diffHours += 24;
    if (diffHours <= 0.0003) { cdEl.textContent = "নামাজের সময় হয়েছে"; return; }
    const totalSec = Math.round(diffHours * 3600);
    const h = Math.floor(totalSec / 3600), m = Math.floor((totalSec % 3600) / 60), s = totalSec % 60;
    cdEl.textContent = `বাকিঃ ${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  tick();
  countdownTimer = setInterval(tick, 1000);
}

/* ---------------- LEARN HUB ---------------- */
function renderLearn(container) {
  const categories = [
    { icon: "📖", label: "সূরা", route: "surahs" },
    { icon: "🕌", label: "সালাহ রিসাইটেশন", route: "salah" },
    { icon: "🤲", label: "দুআ", route: "duas" },
    { icon: "📿", label: "যিকর/আযকার", route: "dhikr" },
    { icon: "📝", label: "সালাহ লেসন (ধাপে ধাপে)", route: "salah-guide" },
    { icon: "🧠", label: "মুখস্থকরণ", route: "memorization" },
    { icon: "❓", label: "কুইজ", route: "quiz" },
    { icon: "💧", label: "ওযুর পদ্ধতি", route: "wudu" },
    { icon: "📢", label: "আযান", route: "adhan" },
    { icon: "🔤", label: "ইসলামিক পরিভাষা", route: "terms" },
    { icon: "⚖️", label: "ফিকহ নোট", route: "fiqh" },
    { icon: "❤️", label: "সেভড আইটেম", route: "favorites" },
  ];
  container.innerHTML = `<div class="grid-2">
    ${categories.map((c) => `<div class="quick-action" data-nav="${c.route}" style="padding:20px 10px;">
      <span class="qa-icon" style="font-size:2rem;">${c.icon}</span><span>${esc(c.label)}</span>
    </div>`).join("")}
  </div>`;
  bindNavClicks(container);
}

/* ---------------- MORE ---------------- */
function renderMore(container) {
  const items = [
    { icon: "🕒", label: "নামাজের সময়সূচি", route: "prayer-times" },
    { icon: "🧭", label: "কিবলার দিক", route: "qibla" },
    { icon: "✅", label: "সালাহ ট্র্যাকার", route: "tracker" },
    { icon: "📘", label: "কুরআন রিডিং ট্র্যাকার", route: "quran-tracker" },
    { icon: "🌙", label: "রমজান মোড", route: "ramadan" },
    { icon: "⚖️", label: "ফিকহ নোট", route: "fiqh" },
    { icon: "❤️", label: "সেভড আইটেম", route: "favorites" },
    { icon: "⚙️", label: "সেটিংস", route: "settings" },
  ];
  container.innerHTML = items.map((it) => `<div class="list-item" data-nav="${it.route}">
    <span>${it.icon} ${esc(it.label)}</span><span>›</span>
  </div>`).join("");
  bindNavClicks(container);
}

/* ---------------- Prayer Times detail page ---------------- */
async function renderPrayerTimesPage(container) {
  container.innerHTML = skeletonBlock(4);
  const { label, times, settings } = await prayerTime.getTodayTimes();
  container.innerHTML = `
    <div class="card">
      <h3 style="margin-top:0;">${esc(label)}</h3>
      <p class="muted small">পদ্ধতিঃ ${esc(times.method)} · আসরঃ ${esc(times.asrMethod)}</p>
      ${["fajr","sunrise","dhuhr","asr","maghrib","isha"].map((k) => `
        <div class="list-item"><span>${k==="sunrise"?"সূর্যোদয়":prayerTime.labelsBn()[k]}</span><strong>${times[k]}</strong></div>
      `).join("")}
      <p class="muted small mt-8">⚠️ নামাজের সময় গণনা পদ্ধতি ও অবস্থানভেদে পরিবর্তিত হতে পারে। এটি একটি জ্যোতির্বিজ্ঞানভিত্তিক আনুমানিক হিসাব।</p>
      <button class="btn btn-outline btn-block" data-nav="settings">⚙️ পদ্ধতি/অবস্থান পরিবর্তন করুন</button>
    </div>
  `;
  bindNavClicks(container);
}

/* ---------------- Favorites page ---------------- */
async function renderFavoritesPage(container) {
  const favs = favorites.getFavorites();
  if (!favs.length) {
    container.innerHTML = emptyState("❤️", "এখনো কোনো পছন্দ সংরক্ষিত নেই", "সূরা ও দুআ এখানে দ্রুত অ্যাক্সেসের জন্য সংরক্ষণ করুন।", "খুঁজে দেখুন", "learn");
    bindNavClicks(container);
    return;
  }
  const typeLabels = { surah: "সূরা", recitation: "সালাহ রিসাইটেশন", dua: "দুআ", dhikr: "যিকর" };
  container.innerHTML = favs.map((f) => `<div class="list-item" data-remove="${f.type}:${f.id}">
    <span>${esc(f.meta?.title || f.id)}</span>
    <span class="badge">${esc(typeLabels[f.type] || f.type)}</span>
  </div>`).join("");
  container.querySelectorAll("[data-remove]").forEach((el) => {
    el.addEventListener("click", () => {
      const [type, id] = el.dataset.remove.split(":");
      favorites.removeFavorite(type, id);
      renderFavoritesPage(container);
      toast("সরানো হয়েছে");
    });
  });
}

/* ---------------- Quran reading tracker ---------------- */
function renderQuranTracker(container) {
  const progress = getItem("quranJuzProgress", {});
  container.innerHTML = `<div class="card"><p class="muted small">এটি একটি ব্যক্তিগত তিলাওয়াত ট্র্যাকার মাত্র — প্রতিটি জুযের জন্য আপনার অগ্রগতি (%) ম্যানুয়ালি রেকর্ড করুন।</p></div>
    ${Array.from({ length: 30 }, (_, i) => i + 1).map((juz) => {
      const pct = progress[juz] || 0;
      return `<div class="card" style="padding:12px;">
        <div class="card-row"><strong>জুয ${juz}</strong><span class="muted small">${pct}%</span></div>
        <input type="range" min="0" max="100" step="5" value="${pct}" data-juz="${juz}" style="width:100%;">
      </div>`;
    }).join("")}`;
  container.querySelectorAll("[data-juz]").forEach((input) => {
    input.addEventListener("change", (e) => {
      progress[e.target.dataset.juz] = Number(e.target.value);
      setItem("quranJuzProgress", progress);
      toast("সংরক্ষিত হয়েছে");
    });
  });
}

/* ---------------- Terms (glossary) ---------------- */
async function renderTerms(container) {
  container.innerHTML = skeletonBlock(4);
  try {
    const res = await fetch("data/terms.json", { cache: "force-cache" });
    const terms = await res.json();
    container.innerHTML = terms.map((t) => `<div class="card">
      <strong>${esc(t.termBn)}</strong>
      <p class="small" style="margin:4px 0 0;">${esc(t.defBn)}</p>
    </div>`).join("");
  } catch (e) {
    container.innerHTML = emptyState("🔤", "পরিভাষা লোড করা যায়নি", "অফলাইনে ক্যাশ হয়নি।", "হোম", "home");
    bindNavClicks(container);
  }
}

/* ---------------- Route registration ---------------- */
register("home", renderHome, "SalahOS");
register("learn", renderLearn, "শিখুন");
register("surahs", surahMod.renderSurahList, "সূরা লাইব্রেরি");
register("surah-reader", surahMod.renderSurahReader, "সূরা");
register("duas", duaMod.renderDuaLibrary, "দুআ");
register("dhikr", dhikrMod.renderDhikrLibrary, "যিকর/আযকার");
register("tasbih", dhikrMod.renderTasbih, "তাসবীহ");
register("salah", salahMod.renderSalahLibrary, "সালাহ রিসাইটেশন");
register("salah-guide", salahMod.renderSalahGuide, "সালাহ গাইড");
register("salah-simulator", salahMod.renderSalahSimulator, "সালাহ সিমুলেটর");
register("memorization", memo.renderMemorization, "মুখস্থকরণ");
register("quiz", quizMod.renderQuiz, "কুইজ");
register("prayer-times", renderPrayerTimesPage, "নামাজের সময়সূচি");
register("tracker", trackerMod.renderTracker, "সালাহ ট্র্যাকার");
register("favorites", renderFavoritesPage, "সেভড আইটেম");
register("settings", settingsMod.renderSettings, "সেটিংস");
register("ramadan", ramadanMod.renderRamadan, "রমজান মোড");
register("fiqh", fiqhMod.renderFiqh, "ফিকহ নোট");
register("more", renderMore, "আরও");
register("quran-tracker", renderQuranTracker, "কুরআন ট্র্যাকার");
register("terms", renderTerms, "ইসলামিক পরিভাষা");
register("wudu", guides.renderWudu, "ওযুর পদ্ধতি");
register("adhan", guides.renderAdhan, "আযান");
register("qibla", qibla.renderQibla, "কিবলার দিক");

/* ---------------- Boot ---------------- */
dataMod.preloadAll().finally(() => {
  initRouter();
  runOnboardingIfNeeded();
});

// Expose a tiny debug handle (no secrets) for manual QA in the browser console.
window.SalahOS = { navigate };
