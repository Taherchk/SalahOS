// router.js — simple hash router. No page reloads.
const routes = {};
const navMap = {
  home: "home",
  learn: "learn", surahs: "learn", "surah-reader": "learn", duas: "learn",
  memorization: "learn", quiz: "learn", terms: "learn", fiqh: "learn", favorites: "learn", wudu: "learn", adhan: "learn", qibla: "more",
  "salah-guide": "salah-guide", salah: "salah-guide", "salah-simulator": "salah-guide",
  dhikr: "dhikr", tasbih: "dhikr",
  more: "more", "prayer-times": "more", tracker: "more", "quran-tracker": "more", ramadan: "more", settings: "more",
};
let history = [];
let current = null;

export function register(name, renderFn, title) {
  routes[name] = { renderFn, title: title || "SalahOS" };
}

function parseHash() {
  const raw = (location.hash || "#home").slice(1);
  const [route, paramStr] = raw.split("?");
  const params = {};
  if (paramStr) {
    paramStr.split("&").forEach((pair) => {
      const [k, v] = pair.split("=");
      if (k) params[decodeURIComponent(k)] = decodeURIComponent(v || "");
    });
  }
  return { route: route || "home", params };
}

export function navigate(route, params = {}) {
  let hash = "#" + route;
  const qs = Object.entries(params).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&");
  if (qs) hash += "?" + qs;
  location.hash = hash;
}

export function goBack() {
  if (history.length > 1) {
    history.pop();
    const prev = history[history.length - 1];
    navigate(prev.route, prev.params);
  } else {
    navigate("home");
  }
}

function updateChrome(route) {
  const title = routes[route] ? routes[route].title : "SalahOS";
  const titleEl = document.getElementById("pageTitle");
  if (titleEl) titleEl.textContent = title;

  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.route === (navMap[route] || route));
  });

  const backBtn = document.getElementById("btnBack");
  if (backBtn) backBtn.style.display = route === "home" ? "none" : "flex";

  const content = document.getElementById("app-content");
  if (content) content.scrollTop = 0;
  window.scrollTo(0, 0);
}

async function render() {
  const { route, params } = parseHash();
  const entry = routes[route] || routes["home"];
  if (!entry) return;

  if (!current || current.route !== route || JSON.stringify(current.params) !== JSON.stringify(params)) {
    history.push({ route, params });
    if (history.length > 50) history.shift();
  }
  current = { route, params };

  updateChrome(route);
  const content = document.getElementById("app-content");
  if (!content) return;
  try {
    await entry.renderFn(content, params);
  } catch (e) {
    console.error("SalahOS render error for route", route, e);
    content.innerHTML = `<div class="card"><p>⚠️ এই পাতাটি লোড করতে সমস্যা হয়েছে। হোমে ফিরে যান।</p>
      <button class="btn btn-primary" data-nav="home">হোম</button></div>`;
    import("./ui.js").then(({ bindNavClicks }) => bindNavClicks(content));
  }
  import("./ui.js").then(({ bindNavClicks }) => bindNavClicks(content));
}

export function initRouter() {
  window.addEventListener("hashchange", render);
  window.addEventListener("salahos:navigate", (e) => navigate(e.detail.route, e.detail.params || {}));
  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.addEventListener("click", () => navigate(btn.dataset.route));
  });
  const backBtn = document.getElementById("btnBack");
  if (backBtn) backBtn.addEventListener("click", goBack);
  render();
}

export function currentRoute() { return current; }
