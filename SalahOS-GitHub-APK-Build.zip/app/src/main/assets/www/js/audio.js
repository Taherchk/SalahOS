// audio.js — reusable audio player wrapping the single <audio id="globalAudio"> element.
import { getItem, setItem, KEYS } from "./storage.js";
import { toast } from "./ui.js";

const REPEAT_MODES = ["off", "one", "three", "five", "infinite"];
let audioEl = null;
let currentId = null;
let repeatCount = 0;
let repeatTarget = 0;
let onEndedCb = null;

function el() {
  if (!audioEl) audioEl = document.getElementById("globalAudio");
  return audioEl;
}

export function getPrefs() {
  return getItem(KEYS.AUDIO_PREFS, { speed: 1, repeat: "off", volume: 1 });
}
export function setPrefs(p) {
  setItem(KEYS.AUDIO_PREFS, p);
}

export function play(src, id, onEnded) {
  const a = el();
  if (!a) return;
  if (!src) {
    toast("অডিও অফলাইনে পাওয়া যাচ্ছে না। পাঠ্য ও অর্থ পড়ে অনুশীলন করুন।");
    if (onEnded) onEnded();
    return;
  }
  const prefs = getPrefs();
  currentId = id;
  onEndedCb = onEnded;
  repeatCount = 0;
  repeatTarget = { off: 1, one: 1, three: 3, five: 5, infinite: Infinity }[prefs.repeat] ?? 1;
  try {
    a.src = src;
    a.playbackRate = prefs.speed || 1;
    a.volume = prefs.volume ?? 1;
    const p = a.play();
    if (p && p.catch) p.catch((err) => {
      console.warn("SalahOS: audio play blocked or failed", err);
      toast("অডিও চালানো যায়নি। স্ক্রিনে ট্যাপ করে আবার চেষ্টা করুন।");
    });
  } catch (e) {
    toast("অডিও চালানো যায়নি।");
  }
}

export function pause() { const a = el(); if (a) a.pause(); }
export function stop() { const a = el(); if (a) { a.pause(); a.currentTime = 0; } }
export function isPlaying(id) { const a = el(); return !!a && !a.paused && currentId === id; }

export function setSpeed(speed) {
  const a = el();
  if (a) a.playbackRate = speed;
  setPrefs({ ...getPrefs(), speed });
}
export function setRepeatMode(mode) {
  if (!REPEAT_MODES.includes(mode)) mode = "off";
  setPrefs({ ...getPrefs(), repeat: mode });
}

function initEndedHandler() {
  const a = el();
  if (!a) return;
  a.addEventListener("ended", () => {
    repeatCount++;
    if (repeatCount < repeatTarget) {
      a.currentTime = 0;
      const p = a.play();
      if (p && p.catch) p.catch(() => {});
    } else if (onEndedCb) {
      onEndedCb();
    }
  });
  a.addEventListener("error", () => {
    toast("অডিও লোড করা যায়নি।");
  });
}
initEndedHandler();

export function audioControlsHtml(idAttr) {
  const prefs = getPrefs();
  return `
    <div class="audio-row" data-audio-controls="${idAttr}">
      <button class="btn btn-ghost btn-sm" data-act="play">▶️ শুনুন</button>
      <button class="btn btn-ghost btn-sm" data-act="pause">⏸️ থামান</button>
      <select data-act="speed" class="btn-sm" style="width:auto;">
        <option value="0.5" ${prefs.speed==0.5?"selected":""}>0.5x</option>
        <option value="0.75" ${prefs.speed==0.75?"selected":""}>0.75x</option>
        <option value="1" ${(!prefs.speed||prefs.speed==1)?"selected":""}>1x</option>
        <option value="1.25" ${prefs.speed==1.25?"selected":""}>1.25x</option>
      </select>
      <select data-act="repeat" style="width:auto;">
        <option value="off" ${prefs.repeat==="off"?"selected":""}>পুনরাবৃত্তি নেই</option>
        <option value="one" ${prefs.repeat==="one"?"selected":""}>১ বার</option>
        <option value="three" ${prefs.repeat==="three"?"selected":""}>৩ বার</option>
        <option value="five" ${prefs.repeat==="five"?"selected":""}>৫ বার</option>
        <option value="infinite" ${prefs.repeat==="infinite"?"selected":""}>অবিরাম</option>
      </select>
    </div>`;
}

export function bindAudioControls(root, src, id) {
  const wrap = root.querySelector(`[data-audio-controls="${id}"]`);
  if (!wrap) return;
  wrap.querySelector('[data-act="play"]').addEventListener("click", () => play(src, id));
  wrap.querySelector('[data-act="pause"]').addEventListener("click", pause);
  wrap.querySelector('[data-act="speed"]').addEventListener("change", (e) => setSpeed(parseFloat(e.target.value)));
  wrap.querySelector('[data-act="repeat"]').addEventListener("change", (e) => setRepeatMode(e.target.value));
}
