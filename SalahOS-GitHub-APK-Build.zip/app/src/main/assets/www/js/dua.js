// dua.js — Dua library + deterministic "Daily Dua" selection.
import { getDuas } from "./data.js";
import { esc, skeletonBlock, bindNavClicks } from "./ui.js";
import { isFavorite, toggleFavorite } from "./favorites.js";
import * as audio from "./audio.js";

export async function getDailyDua() {
  const duas = await getDuas();
  if (!duas.length) return null;
  const day = Math.floor(Date.now() / 86400000); // deterministic by date
  return duas[day % duas.length];
}

export async function renderDuaLibrary(container) {
  container.innerHTML = skeletonBlock(6);
  const duas = await getDuas();
  const groups = {};
  duas.forEach((d) => { (groups[d.category] = groups[d.category] || []).push(d); });
  container.innerHTML = Object.keys(groups).map((cat) => `
    <div class="card">
      <h3 style="margin-top:0;">${esc(cat)}</h3>
      ${groups[cat].map((d) => duaBlock(d)).join("")}
    </div>
  `).join("") || `<p class="muted">কোনো দুআ পাওয়া যায়নি।</p>`;
  duas.forEach((d) => audio.bindAudioControls(container, d.audio, "dua-" + d.id));
  container.querySelectorAll("[data-fav]").forEach((btn) => {
    btn.addEventListener("click", () => {
      toggleFavorite("dua", btn.dataset.fav, { title: btn.dataset.title });
      btn.textContent = isFavorite("dua", btn.dataset.fav) ? "❤️" : "🤍";
    });
  });
  bindNavClicks(container);
}

export function duaBlock(d) {
  const fav = isFavorite("dua", d.id);
  return `<div class="ayah-block">
    <div class="card-row">
      <strong>${esc(d.titleBn)}</strong>
      <button class="btn btn-ghost btn-sm" data-fav="${d.id}" data-title="${esc(d.titleBn)}">${fav ? "❤️" : "🤍"}</button>
    </div>
    <div class="arabic" style="margin-top:8px;">${esc(d.arabic)}</div>
    <div class="translit">${esc(d.pronunciationBn)}</div>
    <div class="meaning">${esc(d.meaningBn)}</div>
    <p class="muted small">সূত্রঃ ${esc(d.source || "—")}</p>
    ${audio.audioControlsHtml("dua-" + d.id)}
  </div>`;
}
